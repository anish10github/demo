import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Blog = () => {
  const navigate = useNavigate();

  const handleBackClick = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Back Button */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Button
            variant="ghost"
            onClick={handleBackClick}
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gradient-pink-blue mb-4">
            Immersive Studio Blog
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Ideas in motion — thought leadership articles arriving shortly.
          </p>
        </div>

        {/* PDF Presentation */}
        <div className="max-w-6xl mx-auto">
          <div className="bg-card border border-border rounded-xl p-4">
            <iframe
              src="https://indegene123-my.sharepoint.com/:b:/g/personal/anish_m_indegene_com/ES4Uief35tZLtIycSpghJrYBj64CtJN9W02qk-BnNjZFow?web=1"
              width="100%"
              height="600"
              frameBorder="0"
              className="rounded-lg"
              title="Immersive Studio Blog Document"
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Blog;