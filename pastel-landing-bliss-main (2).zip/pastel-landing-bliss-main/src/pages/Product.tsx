import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Home,
  Paperclip,
  Send,
  Sparkles,
  Wand2,
  Image,
  Video,
  FileText,
  Check,
  Loader2,
  Download,
  User,
  Layout,
  Film,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import userAvatar from "@/assets/user-avatar.png";

interface Message {
  role: "user" | "assistant";
  content: string;
  agent?: "ISA" | "EVA";
  buttons?: Array<{ label: string; value: string }>;
}

type ProcessPhase = {
  heading: string;
  steps: Array<{ label: string; isWarning?: boolean; description?: string }>;
  initialDelay?: number;
};

const Product = () => {
  const navigate = useNavigate();
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [showWelcome, setShowWelcome] = useState(true);
  const [formDialogOpen, setFormDialogOpen] = useState(false);
  const [selectedMarketing, setSelectedMarketing] = useState<string>("");
  const [showProcess, setShowProcess] = useState(false);
  const [currentPhaseIndex, setCurrentPhaseIndex] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [processCompleted, setProcessCompleted] = useState(false);
  const [formData, setFormData] = useState({
    hostName: "",
    demandIntake: null as File | null,
    supportingPdf: null as File | null,
    customPrompt: "",
  });
  const chatEndRef = useRef<HTMLDivElement>(null);

  const processPhases: ProcessPhase[] = [
    {
      heading: "Input Phase",
      steps: [{ label: " Input" }],
      initialDelay: 3000,
    },
    {
      heading: "Content Processing",
      steps: [
        { label: " Extract Content" },
        { label: " Summarize Content" },
        { label: " Identify Theme and Objective" },
        { label: " Identify Brand / Non-Brand" },
      ],
    },
    {
      heading: "Guardrail Agent",
      steps: [{ label: " Off-label" }, { label: " Safety Statement" }, { label: " Blacklist Terms" }],
    },
    {
      heading: "Production Agent",
      steps: [
        { label: "Orchestrator assigns Sub-Agent", description: "Coordinates workflows" },
        { label: "Research Agent", description: "Generates insights" },
        { label: "Content Agent", description: "Creates content" },
        { label: "Script Agent", description: "Builds narrative" },
        { label: "QA Agent", description: "Validates quality" },
      ],
    },
    {
      heading: "Compliance Agent",
      steps: [
        { label: "⚠️ Script failed pharma compliance — score 67/100", isWarning: true },
        { label: "🔁 Redirected to Post Production Agent" },
      ],
    },
    {
      heading: "Post Production Agent",
      steps: [
        { label: " Rewriting script based on feedback" },
        { label: " Compliance rechecked" },
        { label: " Script Passed — score 92/100" },
      ],
    },
    {
      heading: "Audio Agent",
      steps: [{ label: "🎧 Converting final script to podcast..." }],
    },
  ];

  useEffect(() => {
    if (!showProcess || currentPhaseIndex >= processPhases.length) {
      if (showProcess && currentPhaseIndex >= processPhases.length) {
        // All phases complete
        setTimeout(() => {
          setProcessCompleted(true);
          setMessages((prev) => [
            ...prev,
            {
              role: "assistant",
              content: "Ganeshk, your podcast is successfully generated!, It’s ready for Download.",
              agent: "EVA",
            },
            {
              role: "assistant",
              content: "Ganeshk, Would you like to create another podcast or explore other creations?",
              agent: "ISA",
            },
          ]);
        }, 1000);
      }
      return;
    }

    const currentPhase = processPhases[currentPhaseIndex];

    if (currentStepIndex < currentPhase.steps.length) {
      // Still steps to process in current phase
      const delay = currentStepIndex === 0 && currentPhase.initialDelay ? currentPhase.initialDelay : 2000; // 2 seconds delay

      const timer = setTimeout(() => {
        setCurrentStepIndex((prev) => prev + 1);
      }, delay);

      return () => clearTimeout(timer);
    } else {
      // Current phase complete, move to next phase
      const timer = setTimeout(() => {
        setCurrentPhaseIndex((prev) => prev + 1);
        setCurrentStepIndex(0);
      }, 500); // Small delay before showing next phase

      return () => clearTimeout(timer);
    }
  }, [showProcess, currentPhaseIndex, currentStepIndex]);

  // Auto-scroll to newest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const toolbarItems = [
    { icon: Sparkles, label: "Generate", active: true },
    { icon: Wand2, label: "Brand Kit" },
    { icon: Image, label: "Images" },
    { icon: Video, label: "Videos" },
    { icon: FileText, label: "Podcast" },
    { icon: User, label: "Account", userImage: userAvatar },
  ];

  const handleMarketingSelect = (type: string) => {
    setSelectedMarketing(type);
    setFormDialogOpen(true);
  };

  const handleFormSubmit = async () => {
    setFormDialogOpen(false);

    // Send data to webhook with files
    const webhookUrl =
      "https://primary-production-f8104.up.railway.app/webhook-test/d3e5de94-7602-42d6-88e8-80a4c33e1554";
    const formDataToSend = new FormData();

    formDataToSend.append("hostName", formData.hostName);
    formDataToSend.append("customPrompt", formData.customPrompt);
    formDataToSend.append("marketingType", selectedMarketing);
    formDataToSend.append("timestamp", new Date().toISOString());

    if (formData.demandIntake) {
      formDataToSend.append("demandIntake", formData.demandIntake);
    }

    if (formData.supportingPdf) {
      formDataToSend.append("supportingPdf", formData.supportingPdf);
    }

    try {
      await fetch(webhookUrl, {
        method: "POST",
        body: formDataToSend,
      });
    } catch (error) {
      console.error("Webhook error:", error);
    }

    setShowProcess(true);
    setCurrentPhaseIndex(0);
    setCurrentStepIndex(0);
    setProcessCompleted(false);
  };

  const generateISAResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.includes("podcast")) {
      return "🤖 ISA: Hi Ganeshk, I'll guide you step by step to create a podcast for your brand.\nLet me introduce you to our Podcast Agent, EVA.";
    } else if (lowerMessage.includes("video")) {
      return "Perfect! NOVA, our Video Agent, specializes in creating stunning video content. To help you best, please tell me:\n\n1. What type of video do you need? (explainer, promotional, tutorial, etc.)\n2. What's the main message or story?\n3. Any specific visual style or references?\n4. Preferred video length?\n\nShare these details and NOVA will bring your vision to life!";
    } else if (lowerMessage.includes("animation")) {
      return "Excellent! ANI, our Animation Agent, can create captivating animated content. To get started, I need:\n\n1. What style of animation? (2D, 3D, motion graphics, etc.)\n2. What's the concept or story?\n3. Character requirements or brand elements?\n4. Duration and format?\n\nProvide these details and ANI will create amazing animations for you!";
    } else {
      return "Hello! I'm ISA, your Orchestration Agent. I can help you create:\n\n🎙️ **Podcasts** with EVA\n🎬 **Videos** with NOVA\n🎨 **Animations** with ANI\n\nWhat would you like to create today?";
    }
  };

  const handleSend = () => {
    if (!prompt.trim()) return;

    setShowWelcome(false);

    // Add user message
    const userMessage: Message = {
      role: "user",
      content: prompt,
    };

    setMessages((prev) => [...prev, userMessage]);

    const lowerMessage = prompt.toLowerCase();

    // Generate ISA response
    const isaResponse: Message = {
      role: "assistant",
      content: generateISAResponse(prompt),
      agent: "ISA",
    };

    // Add ISA response immediately
    setTimeout(() => {
      setMessages((prev) => [...prev, isaResponse]);

      // If podcast request, show EVA message after 2 seconds
      if (lowerMessage.includes("podcast")) {
        setTimeout(() => {
          const evaResponse: Message = {
            role: "assistant",
            content:
              "🤖 EVA: Hi Ganeshk, I'm EVA, your Podcast Agent.\nI'll help turn your ideas into a professional podcast.\nPlease choose the Target Audience.",
            agent: "EVA",
          };
          setMessages((prev) => [...prev, evaResponse]);

          // Show guardrail info message after 1 second
          setTimeout(() => {
            const guardrailInfo: Message = {
              role: "assistant",
              content:
                "HCP and Patient Engagement - Pharma and Podcast Guardrail Applied.\nInternal Engagement - Podcast Guardrail Applied.",
              agent: "EVA",
            };
            setMessages((prev) => [...prev, guardrailInfo]);

            // Show buttons after another second
            setTimeout(() => {
              const buttonsMessage: Message = {
                role: "assistant",
                content: "",
                agent: "EVA",
                buttons: [
                  { label: "Internal Engagement", value: "internal" },
                  { label: "HCP & Patient Engagement", value: "external" },
                ],
              };
              setMessages((prev) => [...prev, buttonsMessage]);
            }, 1000);
          }, 1000);
        }, 2000);
      }
    }, 500);

    setPrompt("");
  };

  return (
    <div className="h-screen bg-black text-white flex flex-col">
      {/* Header - Removed */}

      <div className="flex flex-1 overflow-hidden">
        {/* Left Toolbar */}
        <div className="group w-16 hover:w-48 bg-gradient-to-b from-purple-950 to-black border-r border-purple-900/30 flex flex-col py-6 gap-6 transition-all duration-300 overflow-hidden">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="text-purple-400 hover:text-purple-300 hover:bg-purple-900/30 mx-2 justify-start px-3"
          >
            <Home className="w-6 h-6 min-w-6" />
            <span className="ml-3 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Home</span>
          </Button>

          <div className="h-px bg-purple-800/50 mx-2" />

          {toolbarItems.map((item, idx) => (
            <Button
              key={idx}
              variant="ghost"
              className={`${
                item.active
                  ? "text-purple-400 bg-purple-900/50"
                  : "text-gray-400 hover:text-purple-300 hover:bg-purple-900/30"
              } mx-2 justify-start px-3 relative`}
              title={item.label}
            >
              {item.userImage ? (
                <div className="w-5 h-5 min-w-5 rounded-full overflow-hidden">
                  <img src={item.userImage} alt={item.label} className="w-full h-full object-cover" />
                </div>
              ) : (
                <item.icon className="w-5 h-5 min-w-5" />
              )}
              <span className="ml-3 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                {item.label}
              </span>
            </Button>
          ))}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Side - Chat/Prompt Area (40%) */}
          <div className="w-[40%] border-r border-purple-900/30 flex flex-col" style={{ backgroundColor: "#1F1F1F" }}>
            <div className="p-6 border-b border-purple-900/30">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-400 via-blue-400 to-white bg-clip-text text-transparent">
                Chat Mode
              </h1>
              <p className="text-sm text-gray-400 mt-1">Where Ideas Meet Execution</p>
            </div>

            {/* Chat Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-3 chat-scrollbar">
              {/* Welcome Message */}
              {showWelcome && (
                <>
                  <div className="bg-purple-950/30 border border-purple-900/30 rounded-lg p-4">
                    <p className="text-sm text-purple-300">
                      👋 Welcome to Immersive Studio, Ganeshk! I'm ISA, your Orchestration Agent. Tell me what you'd
                      like to create — a podcast, video, or animation — and I'll guide you through it.
                    </p>
                  </div>

                  {/* Feature Pointers */}
                  <div className="flex flex-wrap gap-2 mt-3">
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-purple-950/20 border border-purple-800/30 rounded-md hover:bg-purple-950/40 hover:border-purple-700/50 transition-all">
                      <Sparkles className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                      <span className="text-xs text-purple-200">Intelligent Collaboration</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-purple-950/20 border border-purple-800/30 rounded-md hover:bg-purple-950/40 hover:border-purple-700/50 transition-all">
                      <Wand2 className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                      <span className="text-xs text-purple-200">Autonomous Content Creation</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-purple-950/20 border border-purple-800/30 rounded-md hover:bg-purple-950/40 hover:border-purple-700/50 transition-all">
                      <Video className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                      <span className="text-xs text-purple-200">Instant Media Production</span>
                    </button>
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-purple-950/20 border border-purple-800/30 rounded-md hover:bg-purple-950/40 hover:border-purple-700/50 transition-all">
                      <FileText className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                      <span className="text-xs text-purple-200">Dynamic Coordination</span>
                    </button>
                  </div>
                </>
              )}

              {/* Conversation Messages */}
              {messages.map((message, index) => (
                <div key={index}>
                  {message.content && (
                    <div
                      className={`rounded-xl p-3 ${
                        message.role === "user"
                          ? "bg-purple-900/30 border-2 border-pink-500 ml-8"
                          : message.agent === "ISA"
                            ? "border-2 border-blue-500 mr-8"
                            : message.agent === "EVA"
                              ? "border-2 border-purple-500 mr-8"
                              : "bg-purple-950/30 border border-purple-900/30 mr-8"
                      }`}
                    >
                      {message.role === "assistant" && message.agent && (
                        <p className="text-xs font-semibold text-purple-300 mb-1">{message.agent}</p>
                      )}
                      <p className="text-sm text-white whitespace-pre-wrap leading-relaxed">{message.content}</p>
                    </div>
                  )}
                  {message.buttons && (
                    <div className="flex gap-3 mt-3 mr-8">
                      {message.buttons.map((button, btnIdx) => (
                        <Button
                          key={btnIdx}
                          onClick={() => handleMarketingSelect(button.value)}
                          className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                        >
                          {button.label}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            {/* Prompt Input Area */}
            <div className="p-4 border-t border-purple-900/30">
              <div className="relative">
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe what you want to create..."
                  className="w-full bg-purple-950/20 border-purple-800/50 text-white placeholder:text-gray-500 resize-none pr-20 min-h-[100px] focus:border-purple-600 focus:ring-purple-600/20"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                />
                <div className="absolute bottom-3 right-3 flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-purple-400 hover:text-purple-300 hover:bg-purple-900/30"
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={handleSend}
                    size="icon"
                    className="h-8 w-8 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                    disabled={!prompt.trim()}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-2">Press Enter to send, Shift+Enter for new line</p>
            </div>
          </div>

          {/* Right Side - Agent Cards & Content (60%) */}
          <div className="w-[60%] flex flex-col bg-gradient-to-br from-black via-purple-950/10 to-black p-6">
            {/* Process Flow Log - Always Visible with Scrolling */}
            <div className="flex-1 overflow-y-auto">
              <div className="max-w-2xl mx-auto w-full p-4">
                {!showProcess ? (
                  <div className="bg-purple-950/30 border border-purple-900/30 rounded-lg p-6">
                    <h3 className="text-lg font-bold text-center text-white mb-4 leading-tight">
                      From Concept to Creation: AI Agents That Do the Work for You.
                    </h3>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-purple-900/30 border border-purple-800/30 rounded-lg p-2 text-center hover:bg-purple-900/50 transition-colors cursor-pointer">
                        <Video className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                        <p className="text-xs text-gray-300">Text to Video</p>
                      </div>
                      <div className="bg-purple-900/30 border border-purple-800/30 rounded-lg p-2 text-center hover:bg-purple-900/50 transition-colors cursor-pointer">
                        <Image className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                        <p className="text-xs text-gray-300">Text to Image</p>
                      </div>
                      <div className="bg-purple-900/30 border border-purple-800/30 rounded-lg p-2 text-center hover:bg-purple-900/50 transition-colors cursor-pointer">
                        <Sparkles className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                        <p className="text-xs text-gray-300">Text to Podcast</p>
                      </div>
                      <div className="bg-purple-900/30 border border-purple-800/30 rounded-lg p-2 text-center hover:bg-purple-900/50 transition-colors cursor-pointer">
                        <Layout className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                        <p className="text-xs text-gray-300">Text to Storyboard</p>
                      </div>
                      <div className="bg-purple-900/30 border border-purple-800/30 rounded-lg p-2 text-center hover:bg-purple-900/50 transition-colors cursor-pointer">
                        <Film className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                        <p className="text-xs text-gray-300">Video to Video</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-purple-950/30 border border-purple-900/30 rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-6 text-center bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                      Processing Your Podcast
                    </h3>

                    {/* Process Log - All Phases */}
                    <div className="space-y-6">
                      {processPhases.map((phase, phaseIdx) => {
                        // Show all completed phases and the current phase
                        if (phaseIdx > currentPhaseIndex) return null;

                        const isCurrentPhase = phaseIdx === currentPhaseIndex;

                        return (
                          <div key={phaseIdx}>
                            <h4 className="text-md font-semibold text-purple-300 mb-3">{phase.heading}</h4>
                            <div className="space-y-2">
                              {phase.steps.map((step, stepIdx) => {
                                // For current phase, show completed steps and active step
                                if (isCurrentPhase && stepIdx > currentStepIndex) return null;

                                const isActiveStep = isCurrentPhase && stepIdx === currentStepIndex;

                                return (
                                  <div
                                    key={stepIdx}
                                    className={`flex items-center gap-3 p-2 rounded-lg ${
                                      isActiveStep
                                        ? "bg-purple-800/30 border border-purple-700/50"
                                        : step.isWarning
                                          ? "bg-yellow-900/20 border border-yellow-700/30"
                                          : "bg-purple-900/20 border border-purple-800/30"
                                    }`}
                                  >
                                    {isActiveStep ? (
                                      <Loader2 className="w-4 h-4 text-purple-400 animate-spin flex-shrink-0" />
                                    ) : (
                                      <Check
                                        className={`w-4 h-4 ${step.isWarning ? "text-yellow-400" : "text-green-400"} flex-shrink-0`}
                                      />
                                    )}
                                    <div className="flex-1">
                                      <span
                                        className={`text-sm ${step.isWarning ? "text-yellow-300" : "text-purple-200"}`}
                                      >
                                        {step.label}
                                      </span>
                                      {step.description && (
                                        <p className="text-xs italic text-gray-400 mt-0.5">- {step.description}</p>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {processCompleted && (
                      <div className="mt-6 text-center">
                        <Button className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white">
                          <Download className="w-4 h-4 mr-2" />
                          Download Podcast
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Podcast Form Dialog */}
      <Dialog open={formDialogOpen} onOpenChange={setFormDialogOpen}>
        <DialogContent className="bg-purple-950 border-purple-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {selectedMarketing === "external" ? "HCP & Patient Engagement" : "Internal Engagement"}
              {selectedMarketing === "external"}
              {selectedMarketing === "internal"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div>
              <Label htmlFor="hostName" className="text-purple-300">
                Host Name
              </Label>
              <Input
                id="hostName"
                value={formData.hostName}
                onChange={(e) => setFormData({ ...formData, hostName: e.target.value })}
                className="bg-purple-900/30 border-purple-700 text-white mt-1"
                placeholder="Enter host name"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label htmlFor="demandIntake" className="text-purple-300">
                  Demand Intake
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    // Add download logic here - for now it's a placeholder
                    const link = document.createElement("a");
                    link.href = "#"; // Replace with actual template URL
                    link.download = "Demand_Intake_Template.pdf";
                    link.click();
                  }}
                  className="text-purple-400 hover:text-purple-300 text-xs h-auto py-1 px-2"
                >
                  <Download className="w-3 h-3 mr-1" />
                  Download Template
                </Button>
              </div>
              <Input
                id="demandIntake"
                type="file"
                onChange={(e) => setFormData({ ...formData, demandIntake: e.target.files?.[0] || null })}
                className="bg-purple-900/30 border-purple-700 text-white mt-1 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-gradient-to-r file:from-pink-500 file:to-purple-500 file:text-white hover:file:from-pink-600 hover:file:to-purple-600 file:cursor-pointer"
              />
            </div>

            <div>
              <Label htmlFor="supportingPdf" className="text-purple-300">
                Supporting PDF
              </Label>
              <Input
                id="supportingPdf"
                type="file"
                accept=".pdf"
                onChange={(e) => setFormData({ ...formData, supportingPdf: e.target.files?.[0] || null })}
                className="bg-purple-900/30 border-purple-700 text-white mt-1 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-gradient-to-r file:from-pink-500 file:to-purple-500 file:text-white hover:file:from-pink-600 hover:file:to-purple-600 file:cursor-pointer"
              />
            </div>

            <div>
              <Label htmlFor="customPrompt" className="text-purple-300">
                Custom Prompt
              </Label>
              <Textarea
                id="customPrompt"
                value={formData.customPrompt}
                onChange={(e) => setFormData({ ...formData, customPrompt: e.target.value })}
                className="bg-purple-900/30 border-purple-700 text-white mt-1 min-h-[100px]"
                placeholder="Enter any custom instructions..."
              />
            </div>

            <Button
              onClick={handleFormSubmit}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
            >
              Submit
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Product;
