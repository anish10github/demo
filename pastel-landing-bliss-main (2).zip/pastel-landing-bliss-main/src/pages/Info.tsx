import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { PenTool, Search, Lightbulb, MessageSquare, Play, ArrowLeft, Sparkles, Video, Image as ImageIcon, Wand2 } from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from 'recharts';
import agent1 from '@/assets/isa-agent-new.png';
import agent2 from '@/assets/eva-agent.png';
import agent3 from '@/assets/nova-agent-new.png';
import agent4 from '@/assets/ani-agent-new.png';

const Info = () => {
  const navigate = useNavigate();
  const [agentsDialogOpen, setAgentsDialogOpen] = useState(false);

  const radarData = [
    { subject: 'Regulatory Alignment', value: 92 },
    { subject: 'Therapeutic Context Awareness', value: 88 },
    { subject: 'Scientific Integrity', value: 95 },
    { subject: 'Content Precision', value: 90 },
    { subject: 'Personalization Intelligence', value: 85 },
    { subject: 'Global Adaptability', value: 87 },
    { subject: 'MLR Optimization', value: 93 },
  ];

  const useCases = [
    {
      icon: PenTool,
      title: 'Image Generation',
      desc: 'Create compliant, high-impact visuals for medical education and brand campaigns.'
    },
    {
      icon: Search,
      title: 'Podcast Creation',
      desc: 'Craft expert-led discussions with scientific depth and conversational flow.'
    },
    {
      icon: Lightbulb,
      title: 'Video Production',
      desc: 'Transform complex mechanisms into visually engaging, scientifically accurate narratives.'
    },
    {
      icon: MessageSquare,
      title: 'Storyboard Design',
      desc: 'Visualize scientific concepts and brand stories for faster review and MLR alignment.'
    }
  ];

  const logos = ['Coppertone', 'Google', 'Tesla', 'Hummel', 'Custom', 'Clarius', 'Cockpit'];

  const agentDetails = [
    {
      id: "ISA",
      name: "ISA",
      description: "ISA is the Orchestrator Agent that manages the workflow and guides the user through all processes.",
      capabilities: ["Manage and organize sub-agents", "Assign tasks to respective agents for their work"],
      inputs: ["Text Conversation"],
      reporting: "EVA, NOVA, ANI are reporting to me",
      icon: Sparkles,
      image: agent1,
      color: "border-purple-400/50"
    },
    {
      id: "EVA",
      name: "EVA",
      description: "EVA is the Podcast Agent that helps generate podcast voiceovers for your brand.",
      capabilities: [
        "Generate podcast voiceover",
        "Adaptable for internal and external marketing",
        "Scalable to dual-speaker podcast",
      ],
      inputs: ["Host Name", "Add-ons", "Demand Intake", "Custom Prompt"],
      reporting: "I am reporting to ISA",
      icon: Video,
      image: agent2,
      color: "border-blue-400/50"
    },
    {
      id: "NOVA",
      name: "NOVA",
      description: "NOVA is the Video Agent that manages all video-related tasks, including production and editing.",
      capabilities: [
        "Create video content from inputs",
        "Integrate with podcast or animation workflows",
        "Scalable to multiple formats",
      ],
      inputs: ["Video script or storyboard", "Media assets"],
      reporting: "Reports to ISA",
      icon: ImageIcon,
      image: agent3,
      color: "border-pink-400/50"
    },
    {
      id: "ANI",
      name: "ANI",
      description: "ANI is the Animation Agent that creates animated content for videos, podcasts, or marketing materials.",
      capabilities: ["Generate animations from scripts or prompts", "Integrate with podcast and video workflows"],
      inputs: ["Animation storyboard or script", "Assets / character specifications"],
      reporting: "Reports to ISA",
      icon: Wand2,
      image: agent4,
      color: "border-purple-400/50"
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Header */}
      <header className="absolute top-4 left-4 z-50">
        <Button 
          onClick={() => navigate('/')}
          variant="ghost"
          className="text-white/80 hover:text-white hover:bg-white/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </header>

      <div className="container mx-auto px-6 py-8 h-screen flex flex-col justify-between">
        {/* Hero Section */}
        <div className="grid grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="leading-tight">
              <span className="text-7xl font-bold block mb-2 text-gradient-pink-blue">Immersive Studio</span>
              <span className="text-3xl font-normal block">Transforming Pharma Content, Instantly</span>
            </h1>
          </div>
          <div className="flex items-center justify-end gap-4">
            <div className="flex flex-col items-center gap-2">
              <div className="relative w-32 h-24">
                <div className="w-32 h-24 rounded-[40px] bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 animate-pulse opacity-80 blur-sm"></div>
                <div className="w-32 h-24 rounded-[40px] bg-gradient-to-br from-blue-400 via-purple-600 to-pink-600 absolute top-0 animate-spin-slow" style={{ animationDuration: '10s' }}></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button size="icon" className="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30">
                    <Play className="w-6 h-6 text-white" fill="white" />
                  </Button>
                </div>
              </div>
              <p className="text-sm text-white/80">Talk to ISA</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Button 
                onClick={() => navigate('/product')}
                className="bg-gradient-to-r from-purple-600 to-black hover:from-purple-700 hover:to-gray-900 rounded-full px-8 py-2 text-white"
              >
                Chat Mode
              </Button>
              <p className="text-sm text-white/70">Chat with Immersive agents</p>
            </div>
          </div>
        </div>

        {/* Agent Use Cases */}
        <div>
          <div className="grid grid-cols-4 gap-3">
            {useCases.map((useCase, idx) => (
              <div 
                key={idx}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-4 hover:bg-white/10 transition-all"
              >
                <useCase.icon className="w-5 h-5 mb-2 text-purple-400" />
                <h3 className="font-semibold text-sm mb-1">{useCase.title}</h3>
                <p className="text-xs text-white/60">{useCase.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-3 gap-6 items-end">
          {/* Radar Chart */}
          <div>
            <div className="bg-white/5 backdrop-blur-sm border border-purple-500/30 rounded-lg p-4 h-48">
              <h3 className="text-sm font-semibold mb-2">Agent Highlights</h3>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#8b5cf6" strokeOpacity={0.3} />
                  <PolarAngleAxis 
                    dataKey="subject" 
                    tick={{ fill: '#fff', fontSize: 10 }}
                  />
                  <Radar 
                    dataKey="value" 
                    stroke="#a78bfa" 
                    fill="#8b5cf6" 
                    fillOpacity={0.6}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Watch Demo Video */}
          <div>
            <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-sm border border-purple-500/30 rounded-lg p-6 h-48 flex flex-col items-center justify-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-3 hover:bg-white/20 transition-all cursor-pointer">
                <Play className="w-8 h-8 text-white" fill="white" />
              </div>
              <h3 className="text-sm font-semibold">See How Pharma Content Comes to Life</h3>
            </div>
          </div>

          {/* AI Bots */}
          <div>
            <div 
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-4 h-48 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-white/10 transition-all"
              onClick={() => setAgentsDialogOpen(true)}
            >
              <h3 className="text-lg font-semibold">Your Pharma Content Agents</h3>
              <div className="flex items-center justify-center gap-4">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-purple-400/50">
                    <img src={agent1} alt="ISA Agent" className="w-full h-full object-cover" />
                  </div>
                  <span className="text-xs text-white/80">ISA</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-blue-400/50">
                    <img src={agent2} alt="EVA Agent" className="w-full h-full object-cover" />
                  </div>
                  <span className="text-xs text-white/80">EVA</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-pink-400/50">
                    <img src={agent3} alt="NOVA Agent" className="w-full h-full object-cover" />
                  </div>
                  <span className="text-xs text-white/80">NOVA</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-purple-400/50">
                    <img src={agent4} alt="ANI Agent" className="w-full h-full object-cover" />
                  </div>
                  <span className="text-xs text-white/80">ANI</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Company Logos */}
        <div className="flex items-center justify-center gap-8 opacity-40">
          {logos.map((logo, idx) => (
            <span key={idx} className="text-sm font-semibold tracking-wider">
              {logo}
            </span>
          ))}
        </div>
      </div>

      {/* All Agents Dialog */}
      <Dialog open={agentsDialogOpen} onOpenChange={setAgentsDialogOpen}>
        <DialogContent className="max-w-6xl bg-gradient-to-br from-purple-950/95 to-black border-purple-800/50 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-500 bg-clip-text text-transparent">
              Your Pharma Content Agents
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-6 mt-4">
            {agentDetails.map((agent) => {
              const Icon = agent.icon;
              return (
                <div 
                  key={agent.id} 
                  className="bg-white/5 backdrop-blur-sm border border-purple-800/50 rounded-lg p-6 space-y-4"
                >
                  {/* Agent Header */}
                  <div className="flex items-start gap-4">
                    <div className={`w-20 h-20 rounded-full overflow-hidden border-2 ${agent.color} flex-shrink-0`}>
                      <img src={agent.image} alt={agent.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-5 h-5 text-purple-400" />
                        <h3 className="text-xl font-bold text-purple-300">{agent.name}</h3>
                      </div>
                      <p className="text-gray-300 text-sm leading-relaxed">{agent.description}</p>
                    </div>
                  </div>

                  {/* Capabilities */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-purple-400 uppercase tracking-wider">Capability</h4>
                    <ul className="space-y-1.5">
                      {agent.capabilities.map((capability, idx) => (
                        <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                          <span className="text-purple-400 mt-1">•</span>
                          <span>{capability}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Inputs */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold text-purple-400 uppercase tracking-wider">Input</h4>
                    <ul className="space-y-1.5">
                      {agent.inputs.map((input, idx) => (
                        <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                          <span className="text-purple-400 mt-1">•</span>
                          <span>{input}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Reporting */}
                  <div className="pt-3 border-t border-purple-800/30">
                    <p className="text-sm">
                      <span className="text-purple-400 font-semibold">Subordinate / Reporting: </span>
                      <span className="text-gray-300">{agent.reporting}</span>
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Info;
