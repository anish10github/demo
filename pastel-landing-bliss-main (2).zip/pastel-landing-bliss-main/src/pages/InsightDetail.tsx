import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header';
import heygenAvatarImage from '@/assets/heygen-avatar-case-study.jpg';
import elevenlabsPodcastImage from '@/assets/elevenlabs-podcast-case-study.jpg';
import heygenKolImage from '@/assets/heygen-kol-case-study.jpg';

const insightData = {
  'heygen-avatar': {
    title: 'From FAQs to Conversations: Patient Engagement with Interactive Avatars',
    category: 'Patient Engagement',
    publishDate: '2025-09-08',
    image: heygenAvatarImage,
    content: {
      subtitle: 'Indegene Enhances Patient Engagement with HeyGen Interactive Avatar',
      customer: 'A leading global pharmaceutical company partnered with Indegene to enhance patient engagement and support in the context of disease awareness and clinical trials. Traditional approaches such as static FAQs and live agent support were costly, inconsistent, and often failed to meet patient expectations. The company aimed to provide instant, reliable, and compliant responses in a way that was multilingual, accessible, and patient-friendly. Indegene implemented a HeyGen-powered Interactive Avatar to address these challenges.',
      challenges: [
        'Low Effectiveness of FAQs – Static content lacked interactivity and failed to build trust.',
        'High Dependency on Live Agents – Human-led support was resource-intensive and inconsistent.',
        'Compliance Requirements – All responses had to align with strict MLR and regulatory standards.',
        'Accessibility Gaps – Patients needed multilingual, clear, and accurate information.',
        'Limited Guidance – Patients lacked structured support for navigating trial eligibility and next steps.'
      ],
      solution: {
        'On-Site Interactive Avatar': [
          'Embedded directly on the patient website to handle disease-related and trial-specific queries in real time.',
          'Enabled both voice and text interaction, allowing patients to engage naturally and choose their preferred mode of communication.',
          'Functioned 24/7, reducing dependency on live agent availability.'
        ],
        'Conversational & Compliant': [
          'Provided patient-centric responses through a multilingual interface, ensuring accessibility for diverse patient populations.',
          'Drew from an MLR-compliant knowledge base, guaranteeing every interaction met strict regulatory standards.',
          'Ensured accuracy, clarity, and consistency across all responses, reducing variability compared to live agents.'
        ],
        'Interactive Guidance': [
          'Allowed patients to ask open-ended questions or follow a structured navigation path.',
          'Delivered guided support across critical areas such as symptoms, treatment options, trial eligibility, and enrollment processes.',
          'Reduced confusion by directing patients toward the right next-step actions, such as connecting with a trial site or accessing educational resources.'
        ],
        'Scalability & Accessibility': [
          'Designed for global rollouts, with multilingual capability enabling outreach across geographies.',
          'Offered centralized control of content updates, ensuring real-time accuracy and compliance.',
          'Delivered a solution that could scale across multiple therapeutic areas and patient programs.'
        ]
      },
      outcomes: [
        '~90% of patients found the content easy to understand.',
        '~50% of patients progressed to next-step actions.',
        '~40% reduction in dependency on live agents.',
        '~30% improvement in qualified patient routing.'
      ],
      lookingAhead: [
        'Scale patient-facing avatars across multiple therapeutic areas and clinical programs.',
        'Extend capabilities to adherence support, dosing guidance, and safety education.',
        'Enhance accessibility with hyper-realistic avatars to build deeper patient trust.',
        'Integrate with EHRs and trial management systems for personalized engagement.'
      ]
    }
  },
  'elevenlabs-podcast': {
    title: 'From Manual Studios to Gen AI Podcasts: Pharma Audio at Scale',
    category: 'Content Creation',
    publishDate: '2025-09-08',
    image: elevenlabsPodcastImage,
    content: {
      subtitle: 'Scaling Pharma Communication with Indegene–Eleven Labs',
      customer: 'A global pharmaceutical company partnered with Indegene to reimagine how audio content was produced and delivered for healthcare professionals (HCPs) and internal teams. Traditional podcast production relied on manual process, repeated editing, and localized re-recordings, which slowed dissemination and inflated costs. These outdated processes also created inconsistency across markets, making it difficult to deliver timely, compliant, and multilingual updates. The company required a digital-first audio solution that could scale globally, reduce turnaround times, and enhance engagement while adhering to pharma\'s strict compliance standards.',
      challenges: [
        'Slow Turnaround – Manual recording and localization cycles delayed delivery of timely medical updates and commercial content.',
        'High Costs – Frequent revisions and local adaptations required repeated studio sessions, driving up expenses.',
        'Limited Global Reach – Lack of multilingual support restricted dissemination across geographies.',
        'Compliance Pressure – Every script and output needed strict MLR alignment before release.',
        'Low Engagement – Existing audio outputs lacked monotonous and uninspiring, limiting HCP recall and overall impact.'
      ],
      solution: {
        'Dynamic Podcast Creation': [
          'Converted MLR-approved scripts into professional-grade podcasts using hyper-realistic AI-generated voices.',
          'Delivered lifelike narration with expressive tone control for different content types (instructional, professional, engaging).'
        ],
        'Script Customization & Control': [
          'Applied pharma script customization with pre-approved prompt libraries to ensure regulatory compliance.',
          'Enabled dynamic tone control (calm, instructive, neutral) and speech modulation (pitch, speed, style) to tailor delivery for HCPs and patients.'
        ],
        'Hyper-Realistic Voice & Cloning': [
          'Leveraged voice cloning to create consistent, brand-aligned voices across regions.',
          'Ensured accurate pronunciation of therapy-specific terminology and product names.',
          'Supported voice imitation for replicating consistency across multiple campaigns.'
        ],
        'Customization with SSML': [
          'Used SSML scripting for fine-grained control of prosody, emphasis, pacing, and clarity.',
          'Improved delivery of complex medical and scientific terminology without compromising accuracy.'
        ],
        'Localization & Global Reach': [
          'Produced multilingual audio in German, Spanish, Italian, and English for inclusivity and accessibility.',
          'Ensured consistent rollout across Germany, US, Netherlands, and Switzerland with centralized workflows.'
        ],
        'Sound & Music Personalization': [
          'Enhanced audio with AI-generated sound effects (SFX) and background tracks to improve listener engagement and professional quality.',
          'Matched tone and theme to specific medical, commercial, or patient-facing content, ensuring polished yet compliant delivery.'
        ]
      },
      outcomes: [
        '~30% faster turnaround in podcast production.',
        '~40% cost reduction in recording and localization.',
        '>90% accuracy in translation and multilingual adaptation.',
        'Expanded reach across 4 key global markets, improving accessibility and inclusivity.',
        'Enhanced engagement with natural-sounding, compliant digital voices that improved credibility and recall.'
      ],
      lookingAhead: [
        'Integrate audio into omnichannel medical and commercial campaigns for broader impact.',
        'SSML-Directed Expressive Audio – Deploy v3 Alpha (Expressive) with SSML scripting to dynamically control prosody, emphasis, pacing, and emotion.',
        'Establish AI-powered audio as a cornerstone of next-generation pharma engagement.',
        'Global Scalability with Local Nuance – Extend multilingual capabilities to additional emerging markets, tailoring delivery to cultural and linguistic contexts without sacrificing compliance.'
      ]
    }
  },
  'heygen-kol': {
    title: 'From Localization to Global Reach: KOL Engagement with Avatars',
    category: 'Global Communications',
    publishDate: '2025-09-08',
    image: heygenKolImage,
    content: {
      subtitle: 'Indegene Solution with HeyGen KOL Avatars',
      customer: 'A global pharmaceutical company partnered with Indegene to transform how Key Opinion Leader (KOL) insights were shared across markets. Traditional KOL videos required manual subtitling, Voice Adaptation, and regional adaptations, which slowed dissemination, increased costs, and risked inconsistency. The company wanted a digital-first, scalable, and compliant solution to amplify KOL impact worldwide while maintaining scientific credibility and relatability.',
      challenges: [
        'Slow Localization – Manual transcription, translation, and adaptation delayed time-to-market.',
        'Inconsistent Messaging – Regional modifications often diluted therapy differentiation and scientific rigor.',
        'Limited Accessibility – Traditional KOL videos lacked inclusivity for multilingual and multicultural HCP audiences.',
        'Compliance Requirements – Every adaptation needed to strictly align with MLR and regulatory guardrails.',
        'Engagement Gaps – Static video formats limited relatability, reducing HCP trust and recall.'
      ],
      solution: {
        'Digital & Hyper-Realistic KOL Avatars': [
          'Designed lifelike hyper realistic avatars replicating the tone, expressions, and delivery style of real KOLs.',
          'Delivered credible and relatable video communications that bridged the gap between global experts and local HCP audiences.'
        ],
        'AI-Powered Localization & Translation': [
          'Automated multilingual transcript generation, translation, and synchronization, reducing adaptation time from weeks to days.',
          'Used AI voice cloning and hyper-realistic voice adaptation to maintain scientific accuracy while adapting tone, rhythm, and phrasing for cultural nuances.',
          'Localized not just the language, but also visuals, avatars, and backgrounds, creating culturally relevant KOL videos for each region.'
        ],
        'Compliance & Governance': [
          'Embedded MLR-approved scripts and promo-material guardrails, ensuring all communications remained compliant with regulatory requirements.',
          'Restricted content to pre-approved scientific repositories, minimizing off-label risk and ensuring consistency across geographies.'
        ],
        'Scalability & Reach': [
          'Enabled seamless global distribution of KOL insights, covering multiple regions, languages, and therapeutic areas.',
          'Supported rapid adaptation for post-conference highlights, new clinical data, and therapy updates, ensuring timely access for HCPs.',
          'Reduced the costs of manual video production and localization, while improving efficiency and scale.'
        ]
      },
      outcomes: [
        'Accelerated localization timelines, cutting adaptation from weeks to days.',
        'Expanded reach, delivering KOL insights in multiple simultaneously.',
        'Improved HCP engagement, with hyper-realistic avatars enhancing scientific trust and recall.',
        '100% compliance adherence with embedded guardrails and workflows.',
        'Cost efficiency, reducing manual video production and localization expenses.'
      ],
      lookingAhead: [
        'Deploy hyper-realistic KOL avatars across congresses, webinars, and HCP portals.',
        'Enhance emotion-aware avatars capable of adapting tone, gestures, and expressions to increase relatability with HCPs.',
        'Extend avatar use into patient-facing initiatives, bringing trial results and therapy guidance to life.',
        'Position KOL avatars as a cornerstone of compliant, next-generation pharma engagement.'
      ]
    }
  }
};

const InsightDetail = () => {
  const { id } = useParams();
  const insight = insightData[id as keyof typeof insightData];

  if (!insight) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Insight Not Found</h1>
          <Link to="/" className="text-primary hover:text-accent">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-br from-background via-secondary/20 to-accent/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Link 
            to="/#insights" 
            className="inline-flex items-center text-primary hover:text-accent transition-colors duration-200 mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Insights
          </Link>
          
          <div className="max-w-4xl">
            <Badge className="bg-primary text-primary-foreground mb-4">
              {insight.category}
            </Badge>
            
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6 leading-tight">
              {insight.title}
            </h1>
            
            <div className="flex items-center text-muted-foreground mb-8">
              <Calendar className="w-4 h-4 mr-2" />
              <span>{new Date(insight.publishDate).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <img
              src={insight.image}
              alt={insight.title}
              className="w-full h-80 lg:h-96 object-cover rounded-2xl shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <article className="prose prose-lg max-w-none">
              
              {/* Case Study Header */}
              <div className="bg-card border border-border rounded-2xl p-8 mb-12">
                <h2 className="text-2xl font-bold text-foreground mb-4">Case Study</h2>
                <h3 className="text-xl font-semibold text-primary mb-6">{insight.content.subtitle}</h3>
                <div className="border-l-4 border-primary pl-6">
                  <p className="text-muted-foreground leading-relaxed">{insight.content.customer}</p>
                </div>
              </div>

              {/* Challenges Section */}
              <section className="mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-8">Challenges</h2>
                <div className="bg-secondary/20 rounded-2xl p-8">
                  <p className="text-muted-foreground mb-6">The company faced key hurdles in modernizing patient engagement:</p>
                  <ul className="space-y-4">
                    {insight.content.challenges.map((challenge, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 rounded-full bg-accent mt-3 flex-shrink-0"></div>
                        <p className="text-foreground">{challenge}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </section>

              {/* Solution Section */}
              <section className="mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-8">The Solution</h2>
                <div className="space-y-8">
                  {Object.entries(insight.content.solution).map(([solutionTitle, points], index) => (
                    <div key={index} className="bg-card border border-border rounded-2xl p-8">
                      <h3 className="text-xl font-semibold text-primary mb-4">{solutionTitle}</h3>
                      <ul className="space-y-3">
                        {points.map((point, pointIndex) => (
                          <li key={pointIndex} className="flex items-start space-x-3">
                            <div className="w-2 h-2 rounded-full bg-primary mt-3 flex-shrink-0"></div>
                            <p className="text-muted-foreground">{point}</p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </section>

              {/* Outcomes Section */}
              <section className="mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-8">Outcomes</h2>
                <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-8">
                  <p className="text-muted-foreground mb-6">The solution delivered measurable results:</p>
                  <div className="grid md:grid-cols-2 gap-6">
                    {insight.content.outcomes.map((outcome, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-3 h-3 rounded-full bg-accent flex-shrink-0"></div>
                        <p className="text-foreground font-medium">{outcome}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Looking Ahead Section */}
              <section className="mb-12">
                <h2 className="text-3xl font-bold text-foreground mb-8">Looking Ahead</h2>
                <div className="bg-card border border-border rounded-2xl p-8">
                  <p className="text-muted-foreground mb-6">The collaboration will expand further to:</p>
                  <ul className="space-y-4">
                    {insight.content.lookingAhead.map((future, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 rounded-full bg-primary mt-3 flex-shrink-0"></div>
                        <p className="text-foreground">{future}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </section>

            </article>
          </div>
        </div>
      </main>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-accent/10 to-secondary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-6">Ready to Transform Your Engagement?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Discover how our AI-powered solutions can revolutionize your patient and healthcare professional engagement.
          </p>
          <Link
            to="/#contact"
            className="inline-flex items-center bg-primary text-primary-foreground px-8 py-4 rounded-full hover:bg-primary/90 transition-all duration-300 text-lg font-semibold shadow-lg hover:shadow-xl"
          >
            Get Started Today
            <ArrowRight className="w-5 h-5 ml-2" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default InsightDetail;