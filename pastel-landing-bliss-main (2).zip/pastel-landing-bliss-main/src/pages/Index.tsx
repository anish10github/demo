import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import PowerfulCapabilitiesSection from '@/components/PowerfulCapabilitiesSection';
import NewsSection from '@/components/NewsSection';
import ImmersiveStudioHighlights from '@/components/ImmersiveStudioHighlights';
import UseCaseSection from '@/components/UseCaseSection';
import FAQSection from '@/components/FAQSection';
import CTASection from '@/components/CTASection';
import useScrollAnimation from '@/hooks/useScrollAnimation';

const Index = () => {
  useScrollAnimation();

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <PowerfulCapabilitiesSection />
        <ImmersiveStudioHighlights />
        <NewsSection />
        <UseCaseSection />
        <FAQSection />
        <CTASection />
      </main>
    </div>
  );
};

export default Index;
