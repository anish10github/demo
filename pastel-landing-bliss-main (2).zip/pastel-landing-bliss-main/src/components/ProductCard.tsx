import { Button } from '@/components/ui/button';
import { Mic, Bot, Film, Camera } from 'lucide-react';

interface ProductCardProps {
  id: string;
  label: string;
  caption: string;
  icon: 'mic' | 'bot' | 'film' | 'camera';
  onClick: (id: string) => void;
  isActive?: boolean;
}

const iconMap = {
  mic: Mic,
  bot: Bot,
  film: Film,
  camera: Camera,
};

const ProductCard = ({ id, label, caption, icon, onClick, isActive }: ProductCardProps) => {
  const IconComponent = iconMap[icon];
  
  return (
    <div 
      className={`product-card group cursor-pointer transition-all duration-300 ${
        isActive ? 'scale-105 shadow-glow' : 'hover:scale-105 hover:shadow-glow'
      }`}
      onClick={() => onClick(id)}
    >
      <div className="text-center space-y-4">
        <div className="text-sm font-bold text-white/90 tracking-wider">
          {label}
        </div>
        
        <div className="w-16 h-16 mx-auto rounded-xl bg-gradient-to-br from-violet-600/20 to-purple-700/20 border border-violet-400/30 flex items-center justify-center group-hover:border-violet-400/50 transition-colors duration-300">
          <IconComponent className="w-8 h-8 text-violet-300" />
        </div>
        
        <div className="text-xs text-gray-300 leading-tight">
          {caption}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;