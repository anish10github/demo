import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What makes Immersive Studio different from other Gen AI platforms?",
    answer: "Immersive Studio is purpose-built for pharma, not a generic Gen AI tool. It evaluates enterprise Gen AI models against 16 pharma-grade quality metrics, uses a multi-modal engine to select the best model per project, and comes with 150+ pre-configured pharma-compliant prompts. Unlike competitors, it integrates compliance scorecards, pharma-specific guardrails, and 12+ fine-tuned open-source models to ensure transparency, accuracy, and regulatory adherence."
  },
  {
    question: "How does Immersive Studio help solve pharma’s content creation bottlenecks?",
    answer: "Pharma content creation often suffers from long cycles, multiple re-shoots, high costs, scalability limits, and compliance risks. Immersive Studio addresses these by: Reducing production timelines from weeks to days with script-to-scene automation.| Eliminating re-shoots via zero reshoot workflow. | Cutting overhead costs by up to 57%. | Delivering MLR-ready content at scale across 20+ languages and 12+ markets."
  },
  {
    question: "What measurable outcomes have clients achieved with Immersive Studio?",
    answer: "Clients have reported proven outcomes, including: 60% faster time-to-market for MLR-ready content. | 57% reduction in production overhead. | Creation of 20+ region-specific variants in minutes. | Significant improvements in consistency, compliance, and audience engagement."
  },
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-gradient-pink-blue mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-muted-foreground">
              Get answers to the most common questions about our platform and services.
            </p>
          </div>

          <div className="fade-in">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-lg px-6 py-2 hover:shadow-md transition-all duration-300"
                >
                  <AccordionTrigger className="text-left text-primary hover:text-accent font-semibold py-6 hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-6 leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>

        </div>
      </div>
    </section>
  );
};

export default FAQSection;