import { Shield, Settings, FileSearch, Scale } from 'lucide-react';

const AgentCards = () => {
  const agents = [
    {
      id: 'guardrail',
      name: 'Guardrail Agent',
      icon: Shield,
      color: 'from-green-500 to-emerald-500',
      description: 'Automated blacklist monitoring, safety compliance checks, and regulatory claims verification to ensure content meets industry standards.',
    },
    {
      id: 'production',
      name: 'Production Agent',
      icon: Settings,
      color: 'from-orange-500 to-red-500',
      description: 'Intelligent orchestration system managing workflow handoffs between research, content creation, and script development processes.',
    },
    {
      id: 'pharma-qa',
      name: 'Pharma QA Agent',
      icon: FileSearch,
      color: 'from-blue-500 to-cyan-500',
      description: 'Specialized medical legal review preparation with MLR-ready documentation and pharmaceutical industry compliance verification.',
    },
    {
      id: 'compliance',
      name: 'Compliance Agent',
      icon: Scale,
      color: 'from-indigo-500 to-purple-500',
      description: 'Comprehensive approval workflow management with full audit trail documentation and regulatory compliance tracking.',
    },
  ];

  return (
    <div className="space-y-8">
      {agents.map((agent, index) => {
        const IconComponent = agent.icon;
        
        return (
          <div key={agent.id} className="flex items-center space-x-8">
            {/* Circular Card */}
            <div className="flex-shrink-0 relative group">
              {/* Outer glow ring */}
              <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${agent.color} opacity-0 blur-lg transition-all duration-300 group-hover:opacity-30 group-hover:scale-125`} />
              
              {/* Main circle */}
              <div className={`relative w-20 h-20 rounded-full bg-gradient-to-r ${agent.color} flex items-center justify-center border-2 border-white/20 shadow-lg transition-all duration-300 group-hover:border-white/40 group-hover:scale-110`}>
                <IconComponent className="w-10 h-10 text-white" />
              </div>
            </div>

            {/* Text Content */}
            <div className="flex-1">
              <h4 className="text-lg font-bold text-white mb-2 bg-gradient-to-r from-violet-300 to-purple-300 bg-clip-text text-transparent">
                {agent.name}
              </h4>
              <p className="text-sm text-gray-300 leading-relaxed">
                {agent.description}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default AgentCards;