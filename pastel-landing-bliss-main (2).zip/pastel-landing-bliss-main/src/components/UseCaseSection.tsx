import { Users, Mic, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import heygenAvatarImage from '@/assets/heygen-avatar-case-study.jpg';
import elevenlabsPodcastImage from '@/assets/elevenlabs-podcast-case-study.jpg';
import heygenKolImage from '@/assets/heygen-kol-case-study.jpg';

const useCases = [
  {
    id: 'heygen-avatar',
    icon: Users,
    title: 'From FAQs to Conversations: Patient Engagement with Interactive Avatars',
    description: 'How Immersive Studio transformed patient engagement by replacing static FAQs and costly live agents with compliant, multilingual HeyGen-powered interactive avatars.',
    category: 'Patient Engagement',
    image: heygenAvatarImage,
    color: 'from-blue-500 to-blue-600'
  },
  {
    id: 'elevenlabs-podcast',
    icon: Mic,
    title: 'From Conventional Podcast to Gen AI Podcasts: Pharma Audio at Scale',
    description: 'Discover how Immersive Studio and Eleven Labs reimagined podcast creation with EVA, cutting costs and production time while ensuring pharma compliance.',
    category: 'Content Creation',
    image: elevenlabsPodcastImage,
    color: 'from-purple-500 to-pink-500'
  },
  {
    id: 'heygen-kol',
    icon: Globe,
    title: 'From Localization to Global Reach: KOL Engagement with Avatars',
    description: 'See how Immersive Studio and HeyGen enabled hyper-realistic KOL avatars to scale insights across geographies with compliance and credibility.',
    category: 'Global Communications',
    image: heygenKolImage,
    color: 'from-green-500 to-emerald-500'
  }
];

const UseCaseSection = () => {
  return (
    <section id="Usecase" className="py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 fade-in">
          <h2 className="text-3xl font-bold text-gradient-pink-blue mb-4">
            Next-Gen Pharma Solutions
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Transforming pharma content with compliant, scalable, and personalized Gen AI solutions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {useCases.map((useCase, index) => (
            <Link
              key={useCase.id}
              to={`/insights/${useCase.id}`}
              className="group bg-card border border-border rounded-xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:scale-105 fade-in"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Case Study Image */}
              <div className="relative h-32 overflow-hidden">
                  <img
                    src={useCase.image}
                    alt={useCase.title}
                    className="w-full h-full object-cover transition-transform duration-300"
                  />
                <div className="absolute top-3 left-3">
                  <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                    {useCase.category}
                  </span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <div className="p-4 space-y-3">
                {/* Icon with gradient background */}
                <div className="relative mb-3">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${useCase.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <useCase.icon className="w-5 h-5 text-white" />
                  </div>
                </div>

                <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors duration-300 line-clamp-2">
                  {useCase.title}
                </h3>
                <p className="text-muted-foreground text-sm line-clamp-2 leading-relaxed">
                  {useCase.description}
                </p>

                <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
                  <span>Case Study</span>
                  <div className="flex items-center space-x-2 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <span className="text-xs font-medium">Read More</span>
                    <div className="w-0 h-0 border-l-[6px] border-l-current border-y-[3px] border-y-transparent" />
                  </div>
                </div>
              </div>

              {/* Hover effect border */}
              <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-accent/50 transition-all duration-300"></div>
            </Link>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-12 fade-in">
          <p className="text-base text-muted-foreground mb-4">
            Explore how our solutions transform pharma content creation across different use cases.
          </p>
          <Link to="/insights" className="text-primary hover:text-accent font-semibold transition-colors duration-200">
            View All Case Studies →
          </Link>
        </div>
      </div>
    </section>
  );
};

export default UseCaseSection;