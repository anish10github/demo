import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section id="hero" className="min-h-screen flex items-center bg-hero pt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8 fade-in">
            <div className="space-y-6">
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold leading-tight">
                <span className="text-gradient-pink-blue block text-5xl sm:text-6xl lg:text-8xl">Immersive Studio</span>
                <span className="text-black text-2xl sm:text-3xl lg:text-4xl block">
                  Where Pharma Content Comes Alive
                </span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl">
                Redefine how content is created with Immersive Studio a pharma ready Gen AI platform that transforms
                complex science into compliant, engaging audio-visual stories at scale.
              </p>
            </div>
          </div>

          {/* Hero Video Slot */}
          <div className="lg:order-2 fade-in">
            <div className="relative">
              <div className="aspect-video w-full rounded-2xl shadow-2xl overflow-hidden border border-white/20 bg-black">
                <video
                  src="https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EZj-4GNLQVhDmLvbMDgQuKEBacEzWz31ZQWXFfb_HvJwsw?download=1"
                  controls
                  className="w-full h-full object-contain rounded-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
