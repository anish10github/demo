import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sparkles, Video, Image as ImageIcon, Wand2 } from 'lucide-react';

interface AgentDetails {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
  inputs: string[];
  reporting: string;
  icon: 'sparkles' | 'video' | 'image' | 'wand';
  imagePlaceholder: string;
}

const iconMap = {
  sparkles: Sparkles,
  video: Video,
  image: ImageIcon,
  wand: Wand2,
};

interface AgentDetailsDialogProps {
  agent: AgentDetails | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const AgentDetailsDialog = ({ agent, open, onOpenChange }: AgentDetailsDialogProps) => {
  if (!agent) return null;

  const Icon = iconMap[agent.icon];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-gradient-to-br from-purple-950/95 to-black border-purple-800/50 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-500 bg-clip-text text-transparent">
            Agent Details
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Image Slot and Name */}
          <div className="flex items-start gap-6">
            <div className="w-24 h-24 rounded-xl border border-purple-800/50 flex items-center justify-center flex-shrink-0 overflow-hidden">
              <img src={agent.imagePlaceholder} alt={agent.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-purple-300 mb-2">{agent.name}</h3>
              <p className="text-gray-300 text-sm leading-relaxed">{agent.description}</p>
            </div>
          </div>

          {/* Capability Section */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-purple-400 uppercase tracking-wider">Capability</h4>
            <ul className="space-y-2">
              {agent.capabilities.map((capability, idx) => (
                <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>{capability}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Input Section */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-purple-400 uppercase tracking-wider">Input</h4>
            <ul className="space-y-2">
              {agent.inputs.map((input, idx) => (
                <li key={idx} className="text-gray-300 text-sm flex items-start gap-2">
                  <span className="text-purple-400 mt-1">•</span>
                  <span>{input}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Reporting Section */}
          <div className="pt-4 border-t border-purple-800/30">
            <p className="text-sm">
              <span className="text-purple-400 font-semibold">Subordinate / Reporting: </span>
              <span className="text-gray-300">{agent.reporting}</span>
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AgentDetailsDialog;
