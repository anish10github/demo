import { useEffect, useRef } from "react";

const PowerfulCapabilitiesSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll(".capability-card");
            cards.forEach((card, index) => {
              setTimeout(() => {
                card.classList.add("animate-in");
              }, index * 150);
            });
          }
        });
      },
      { threshold: 0.2 },
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const capabilities = [
    {
      title: "Avatar Video",
      description:
        "Lifelike avatar explainers in multiple languages fast and compliant. Ideal for patient education, HCP updates, and congress highlights.",
      colorClass: "avatar-card",
      ringClass: "avatar-ring",
      videoSrc:
        "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EVKeNKhTiMpKtSDW0s4bzZUBIukqinY0qZD4lxZMtJDs7Q?download=1",
      subCard: {
        tagline: "Built-in pharma guardrails · 10× faster · Scalable localization · MLR aligned",
        bullets: ["KOL Videos", "Learning & Development Videos", "Training & Conferences"],
        gradient: "bg-gradient-to-br from-blue-50 to-blue-100",
        direction: "right",
      },
    },
    {
      title: "Gen AI Video",
      description:
        "Storyboard-to-screen in days with cinematic presets and smart cameras. Consistent characters and audit-ready outputs for regulated content.",
      colorClass: "immersive-card",
      ringClass: "immersive-ring",
      videoSrc:
        "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EW_v2f8d1t5Bmmc1vzGhpWIBhp_bRTGTUIQkGEMA9n9cQw?download=1",
      subCard: {
        tagline: "Gen AI–Driven Video Editing for speed, precision, and control",
        bullets: ["Brand Promotion Videos", "Static → Animated Visuals", "Drug Launch Teasers", "HCP Education Bites"],
        gradient: "bg-gradient-to-br from-pink-50 to-pink-100",
        direction: "right",
      },
    },
    {
      title: "Video Podcasting",
      description:
        "Hyper-Realistic voices with SSML control to scale multilingual podcasts. Guardrails ensure accuracy, clarity, and brand-safe delivery.",
      colorClass: "podcasting-card",
      ringClass: "podcasting-ring",
      videoSrc:
        "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EQiFxXz8FYtGhE5jGvkPvvMB2pT7XUYbbLBaEjmbk5ahsw?download=1",
      subCard: {
        tagline: "Immersive experiences with dynamic variability and personalized interactions",
        bullets: [
          "Internal Comms & Leadership Messaging",
          "Brand Storytelling & Patient Journeys",
          "PRD Document → Podcast",
          "Long PDFs → Digestible Content",
        ],
        gradient: "bg-gradient-to-br from-gray-50 to-gray-100",
        direction: "left",
      },
    },
  ];

  // FIX: helper to assign base z per index with Tailwind classes
  const baseZClass = (index: number) => {
    if (index === 0) return "z-[30]";
    if (index === 1) return "z-[20]";
    if (index === 2) return "z-[10]";
    return "z-0";
  };

  return (
    <section
      id="Powerfulcapabilities"
      ref={sectionRef}
      className="py-12 px-4 relative overflow-hidden bg-gradient-to-b from-muted/80 via-muted/60 to-muted/40"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <svg className="w-full h-full" viewBox="0 0 1200 600" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
              <stop offset="50%" stopColor="hsl(var(--accent))" stopOpacity="0.6" />
              <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
            </linearGradient>
          </defs>
          <path
            d="M 50 300 Q 300 200 600 300 T 1150 300"
            stroke="url(#flowGradient)"
            strokeWidth="2"
            fill="none"
            className="animate-pulse"
            style={{ strokeDasharray: "10 5", animation: "flow 8s ease-in-out infinite" }}
          />
          <circle cx="300" cy="250" r="4" fill="hsl(var(--primary))" className="animate-pulse" />
          <circle
            cx="600"
            cy="300"
            r="4"
            fill="hsl(var(--accent))"
            className="animate-pulse"
            style={{ animationDelay: "1s" }}
          />
          <circle
            cx="900"
            cy="250"
            r="4"
            fill="hsl(var(--primary))"
            className="animate-pulse"
            style={{ animationDelay: "2s" }}
          />
        </svg>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-12 fade-in">
          <h2 className="text-3xl md:text-4xl font-bold text-gradient-pink-blue mb-6 relative">
            Powerful Capabilities
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-2 w-20 h-0.5 bg-gradient-to-r from-primary to-accent animate-pulse"></div>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 relative overflow-visible">
          {capabilities.map((capability, index) => (
            <div
              key={capability.title}
              className={`relative group ${baseZClass(index)} ${index === 2 ? "hover:z-[999]" : ""}`}
              style={{
                perspective: "1000px",
                transformStyle: "preserve-3d",
                // FIX: removed inline zIndex, so hover:z-[999] can take effect
              }}
            >
              {/* Main Card */}
              <div
                className={`capability-card glass-card ${capability.colorClass} cursor-pointer opacity-0 translate-y-8 transition-all duration-700 w-80 h-96 mx-auto
                  group-hover:scale-105 group-hover:shadow-2xl
                  [transition:all_300ms_cubic-bezier(0.22,1,0.36,1)]`}
                style={{ animationDelay: `${index * 120}ms` }}
              >
                <h3 className="text-xl font-bold text-center mb-6 text-foreground">{capability.title}</h3>

                {/* Video Slot */}
                <div className="relative mb-6 px-4">
                  <div className={`video-container ${capability.ringClass}`}>
                    <video
                      src={capability.videoSrc}
                      controls
                      className="aspect-video w-full rounded-xl shadow-lg border border-white/20 object-cover"
                    />
                  </div>
                </div>

                {/* Description */}
                <div className="text-center space-y-1">
                  {capability.description.split("\n").map((line, i) => (
                    <p key={i} className="text-sm text-muted-foreground leading-relaxed">
                      {line}
                    </p>
                  ))}
                </div>
              </div>

              {/* Sub Card */}
              <div
                className={`absolute top-0 rounded-xl shadow-lg border border-border/40 p-5 ${capability.subCard.gradient}
                  opacity-0 pointer-events-none 
                  group-hover:opacity-100 group-hover:pointer-events-auto
                  [transition:all_300ms_cubic-bezier(0.22,1,0.36,1)]
                  ${
                    capability.subCard.direction === "right"
                      ? "left-[102%] translate-x-[-20px] group-hover:translate-x-0"
                      : "right-[102%] translate-x-[20px] group-hover:translate-x-0"
                  }`}
                style={{
                  width: "280px",
                  height: "340px",
                  zIndex: 200, // stays high inside the (now) high-z wrapper
                }}
              >
                <div className="h-full flex flex-col justify-center space-y-5">
                  <h4 className="text-lg font-semibold text-foreground text-center">{capability.title}</h4>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground font-medium leading-relaxed">
                      {capability.subCard.tagline}
                    </p>
                  </div>
                  <div className="space-y-3">
                    {capability.subCard.bullets.map((bullet, bulletIndex) => (
                      <div key={bulletIndex} className="flex items-start space-x-3">
                        <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                        <p className="text-sm text-foreground font-medium">{bullet}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PowerfulCapabilitiesSection;
