import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Paperclip } from 'lucide-react';
import ProductionFlow from './ProductionFlow';
import AgentCards from './AgentCards';

const EVADetailSection = () => {
  const [prompt, setPrompt] = useState('');
  const [hostName, setHostName] = useState('');

  return (
    <div className="py-16 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
            <span className="hero-gradient-text">EVA</span> — Podcast Agent
          </h2>
        </div>

        {/* Prompt Panel */}
        <div className="max-w-2xl mx-auto mb-16">
          <div className="bg-gradient-to-br from-violet-900/20 to-purple-900/20 rounded-2xl border border-violet-400/20 p-8 backdrop-blur-sm">
            {/* Prompt Textarea */}
            <div className="mb-6">
              <Textarea
                placeholder="Enter prompt..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[120px] bg-black/20 border-violet-400/30 text-white placeholder:text-gray-400 focus:border-violet-400/50 resize-none"
              />
            </div>

            {/* Attachments */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center space-x-3 p-3 bg-black/20 rounded-lg border border-violet-400/20">
                <Paperclip className="w-4 h-4 text-violet-300" />
                <span className="text-sm text-gray-300">Demand Intake Form</span>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-black/20 rounded-lg border border-violet-400/20">
                <Paperclip className="w-4 h-4 text-violet-300" />
                <span className="text-sm text-gray-300">Add-On's</span>
              </div>
            </div>

            {/* Host Name */}
            <div className="mb-6">
              <Input
                placeholder="Host Name"
                value={hostName}
                onChange={(e) => setHostName(e.target.value)}
                className="bg-black/20 border-violet-400/30 text-white placeholder:text-gray-400 focus:border-violet-400/50"
              />
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white font-semibold py-3 rounded-lg transition-all duration-300 hover:scale-105">
                Generate
              </Button>
              <Button variant="outline" className="flex-1 border-violet-400/30 text-violet-300 hover:bg-violet-900/20 hover:border-violet-400/50">
                Save Draft
              </Button>
            </div>
          </div>
        </div>

        {/* Production Flow */}
        <ProductionFlow />

        {/* Agent Cards */}
        <AgentCards />
      </div>
    </div>
  );
};

export default EVADetailSection;