import { Button } from "@/components/ui/button";
import { ChevronDown, List } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import userAvatar from "@/assets/user-avatar.png";

const Header = () => {
  const navItems = [
    { name: "Capabilities", href: "#Powerfulcapabilities" },
    { name: "Highlights", href: "#Immersivestudiohighlights" },
    { name: "News & Updates", href: "#news" },
    { name: "Case Study", href: "#Usecase" },
    { name: "Roadmap", href: "#roadmap" },
    { name: "FAQ", href: "#faq" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 navbar-blur">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <a href="#hero" aria-label="Go to Home">
              <img
                src="https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EW9wkPkki_JJlHG6G515kKQBix_aLHJ9b0GvTa-kbhyHRQ?download=1"
                alt="Immersive Studio Logo"
                className="h-10 w-auto"
              />
            </a>
          </div>

          {/* Sections Dropdown + CTA Button + User Avatar */}
          <div className="flex items-center gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <List className="h-4 w-4" />
                  Sections
                  <ChevronDown className="h-4 w-4 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {navItems.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <a href={item.href} className="w-full">
                      {item.name}
                    </a>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button className="btn-hero" onClick={() => (window.location.href = "/info")}>
              Agent Mode
            </Button>

            <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <img src={userAvatar} alt="User" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
