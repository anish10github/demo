import { Play, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

const VideoSection = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <section className="py-24 bg-secondary/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12 items-center">
          {/* Video Player - 60% width */}
          <div className="lg:col-span-3 slide-in-left">
            <div className="relative bg-muted rounded-2xl overflow-hidden shadow-2xl">
              {/* Video Placeholder with Play Button */}
              <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                {!isPlaying ? (
                  <button
                    onClick={() => setIsPlaying(true)}
                    className="group bg-background/90 backdrop-blur-sm hover:bg-background text-primary hover:text-accent w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 shadow-lg"
                  >
                    <Play className="w-8 h-8 ml-1" fill="currentColor" />
                  </button>
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <div className="text-muted-foreground">Video Player would be here</div>
                  </div>
                )}
              </div>
              
              {/* Video Controls */}
              <div className="absolute bottom-4 left-4 right-4 bg-background/90 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Product Demo - See it in action
                  </span>
                  <span className="text-sm text-muted-foreground">3:45</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content - 40% width */}
          <div className="lg:col-span-2 space-y-8 slide-in-right">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                See Our Platform
                <span className="text-gradient block">In Action</span>
              </h2>
              <p className="text-lg text-muted-foreground">
                Watch how our intuitive platform transforms complex workflows into simple, streamlined processes. Discover the features that make teams more productive and businesses more successful.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-foreground">Real-time collaboration</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-accent rounded-full"></div>
                <span className="text-foreground">Advanced analytics dashboard</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-foreground">Seamless integrations</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="btn-hero">
                Start Free Trial
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button variant="outline" className="btn-secondary">
                Schedule Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;