import { Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CTASection = () => {
  
  const handleEmailClick = () => {
    window.location.href = 'mailto:genai.immersive@indegene.com';
  };

  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-8 leading-relaxed">
            "Immersive Studio sets a new benchmark for how Gen AI can responsibly accelerate pharma content creation."
          </blockquote>
          
          <div className="space-y-6">
            <p className="text-xl text-muted-foreground">
              Ready to transform your pharma content creation?
            </p>
            
            <Button 
              onClick={handleEmailClick}
              size="lg"
              className="inline-flex items-center gap-2 text-lg px-8 py-4"
            >
              <Mail className="w-5 h-5" />
              genai.immersive@indegene.com
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;