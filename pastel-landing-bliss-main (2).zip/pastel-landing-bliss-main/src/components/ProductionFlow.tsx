import { useState } from 'react';
import { 
  FileText, 
  MessageSquare, 
  Shield, 
  Settings, 
  Search, 
  FileEdit, 
  File, 
  CheckCircle, 
  Scale, 
  Headphones 
} from 'lucide-react';

const ProductionFlow = () => {
  const [hoveredStep, setHoveredStep] = useState<string | null>(null);

  const flowSteps = [
    { id: 'intake', label: 'Demand Intake', icon: FileText, color: 'from-blue-500 to-cyan-500' },
    { id: 'briefing', label: 'Briefing Agent', icon: MessageSquare, color: 'from-purple-500 to-violet-500' },
    { id: 'guardrail', label: 'Guardrail Check', icon: Shield, color: 'from-green-500 to-emerald-500' },
    { 
      id: 'production', 
      label: 'Production Agent', 
      icon: Settings, 
      color: 'from-orange-500 to-red-500',
      subSteps: ['Orchestrator', 'Research', 'Content', 'Script', 'Pharma QA']
    },
    { id: 'compliance', label: 'Compliance Agent', icon: Scale, color: 'from-indigo-500 to-blue-500' },
    { id: 'audio', label: 'Audio Generation', icon: Headphones, color: 'from-pink-500 to-rose-500' },
    { id: 'voiceover', label: 'Podcast Voiceover', icon: FileEdit, color: 'from-teal-500 to-green-500' },
  ];

  return (
    <div className="mb-16">
      <div className="text-center mb-12">
        <h3 className="text-2xl font-bold text-white mb-2">Production Flow</h3>
      </div>

      <div className="relative">
        {/* Flow Container */}
        <div className="flex flex-wrap justify-center items-center gap-8 relative">
          {flowSteps.map((step, index) => {
            const IconComponent = step.icon;
            const isHovered = hoveredStep === step.id;
            
            return (
              <div key={step.id} className="flex items-center">
                {/* Flow Node */}
                <div
                  className={`relative group cursor-pointer transition-all duration-300 ${
                    isHovered ? 'scale-110 z-10' : 'hover:scale-105'
                  }`}
                  onMouseEnter={() => setHoveredStep(step.id)}
                  onMouseLeave={() => setHoveredStep(null)}
                >
                  {/* Glow Effect */}
                  <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${step.color} opacity-0 blur-xl transition-all duration-300 ${
                    isHovered ? 'opacity-30 scale-150' : 'group-hover:opacity-20 group-hover:scale-125'
                  }`} />
                  
                  {/* Main Node */}
                  <div className={`relative w-16 h-16 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center border-2 border-white/20 shadow-lg transition-all duration-300 ${
                    isHovered ? 'border-white/40 shadow-2xl' : 'group-hover:border-white/30'
                  }`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>

                  {/* Label */}
                  <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                    <span className="text-xs text-gray-300 font-medium">{step.label}</span>
                  </div>

                  {/* Sub-steps for Production Agent */}
                  {step.subSteps && isHovered && (
                    <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-black/80 backdrop-blur-sm rounded-lg border border-violet-400/30 p-3 min-w-[200px] z-20">
                      <div className="space-y-1">
                        {step.subSteps.map((subStep, subIndex) => (
                          <div key={subIndex} className="text-xs text-gray-300 flex items-center space-x-2">
                            <div className="w-1 h-1 bg-violet-400 rounded-full" />
                            <span>{subStep}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Connector Line */}
                {index < flowSteps.length - 1 && (
                  <div className="w-8 h-0.5 bg-gradient-to-r from-violet-500/50 to-purple-500/50 mx-2 relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-purple-500 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProductionFlow;