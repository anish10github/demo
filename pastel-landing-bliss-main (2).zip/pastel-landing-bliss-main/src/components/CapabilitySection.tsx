import { Zap, Shield, Rocket, Users, Code, Globe } from 'lucide-react';

const capabilities = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Experience blazing-fast performance with our optimized infrastructure and cutting-edge technology.'
  },
  {
    icon: Shield,
    title: 'Secure by Design',
    description: 'Enterprise-grade security with end-to-end encryption and comprehensive data protection.'
  },
  {
    icon: Rocket,
    title: 'Scale Infinitely',
    description: 'From startup to enterprise, our platform grows with your needs without compromising performance.'
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Seamless collaboration tools that bring teams together and boost productivity across all departments.'
  },
  {
    icon: Code,
    title: 'Developer Friendly',
    description: 'Intuitive APIs, comprehensive documentation, and tools that developers love to work with.'
  },
  {
    icon: Globe,
    title: 'Global Reach',
    description: 'Deploy worldwide with our global CDN and multi-region infrastructure for optimal performance.'
  }
];

const CapabilitySection = () => {
  return (
    <section id="capabilities" className="py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Powerful Capabilities
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Everything you need to build, deploy, and scale your applications with confidence and ease.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {capabilities.map((capability, index) => (
            <div
              key={capability.title}
              className="card-hover fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <capability.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {capability.title}
                </h3>
                <p className="text-muted-foreground">
                  {capability.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CapabilitySection;