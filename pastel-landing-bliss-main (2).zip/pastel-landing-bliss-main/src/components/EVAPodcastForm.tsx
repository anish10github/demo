import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Download, FileText, X } from "lucide-react";
import { toast } from "sonner";

export default function EVAPodcastForm({ onSubmit }: { onSubmit?: (audioUrl: string) => void }) {
  const [hostName, setHostName] = useState("");
  const [marketingType, setMarketingType] = useState<"internal" | "external" | null>(null);
  const [duration, setDuration] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");
  const [showSamplePrompt, setShowSamplePrompt] = useState(false);
  const [addOnFiles, setAddOnFiles] = useState<File[]>([]);
  const [demandIntakeFile, setDemandIntakeFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const addOnInputRef = useRef<HTMLInputElement>(null);
  const demandIntakeInputRef = useRef<HTMLInputElement>(null);

  const samplePromptOptions = [
    {
      title: "Option A",
      content: "Create a podcast episode script from the following content, including an intro and outro. The name of the podcast is [podcast name]. The format of the podcast should be a single-person commentary on the topic. The tone of the podcast should be [engaging/professional/casual], conversational, and maintain the tone of the original content."
    },
    {
      title: "Option B", 
      content: "Create a podcast episode script based entirely on the provided material. The podcast should include a clear intro and outro. The format must be a single-person commentary. The style should be [engaging/professional/casual] and conversational, while preserving the clarity and key details of the source content."
    }
  ];

  const handleUseSamplePrompt = (content: string) => {
    setCustomPrompt(content);
    setShowSamplePrompt(false);
  };

  const handleClearForm = () => {
    setHostName("");
    setMarketingType(null);
    setDuration("");
    setCustomPrompt("");
    setAddOnFiles([]);
    setDemandIntakeFile(null);
  };

  const handleAddOnFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAddOnFiles(prev => [...prev, ...Array.from(e.target.files!)]);
      toast.success(`${e.target.files.length} file(s) added`);
    }
  };

  const handleDemandIntakeFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setDemandIntakeFile(e.target.files[0]);
      toast.success("Demand intake file uploaded");
    }
  };

  const removeAddOnFile = (index: number) => {
    setAddOnFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleFormSubmit = async () => {
    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("hostName", hostName);
      formData.append("marketingType", marketingType || "");
      formData.append("duration", duration);
      formData.append("customPrompt", customPrompt);
      
      if (demandIntakeFile) {
        formData.append("demandIntake", demandIntakeFile);
      }
      
      addOnFiles.forEach((file, index) => {
        formData.append(`addOn_${index}`, file);
      });

      const response = await fetch("https://primary-production-f8104.up.railway.app/webhook-test/a1a3d1ed-6f4f-482f-b31e-f9b7f790d5bb", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const contentType = response.headers.get("content-type");
        
        // Check if response is audio
        if (contentType && contentType.includes("audio/")) {
          const audioBlob = await response.blob();
          const audioUrl = URL.createObjectURL(audioBlob);
          toast.success("Form submitted successfully!");
          onSubmit?.(audioUrl);
        } else {
          toast.success("Form submitted successfully!");
          onSubmit?.("");
        }
      } else {
        toast.error("Submission failed. Please try again.");
      }
    } catch (error) {
      console.error("Submission error:", error);
      toast.error("An error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-left">
          <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-pink-400 to-fuchsia-400 bg-clip-text text-transparent mb-3">
            EVA Podcast Generator
          </h2>
          <p className="text-purple-200/90 text-sm leading-relaxed max-w-3xl">
            Create high-quality, single-speaker podcast voiceovers from your approved inputs—fast, consistent, and pharma-ready.
          </p>
        </div>

        {/* Form */}
        <div className="rounded-3xl border-2 border-purple-500/40 bg-gradient-to-b from-black/60 to-purple-950/20 backdrop-blur-xl p-6 md:p-8 space-y-5 shadow-[0_0_50px_rgba(168,85,247,0.15)]">
          
          {/* Host Name */}
          <div className="space-y-2">
            <Label htmlFor="hostName" className="text-purple-100 font-semibold text-sm">Host Name</Label>
            <Input
              id="hostName"
              placeholder="e.g., Caroline / Eva / Dr. John"
              value={hostName}
              onChange={(e) => setHostName(e.target.value)}
              className="h-10 bg-black/50 border-2 border-purple-500/40 text-slate-100 placeholder-purple-300/50 focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 rounded-xl transition-all"
            />
            <p className="text-xs text-purple-300/60 mt-1">
              This name will be used in the intro/outro and voice attribution.
            </p>
          </div>

          {/* Marketing Type Selection */}
          <div className="space-y-3">
            <Label className="text-purple-100 font-semibold text-sm">Marketing Type</Label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Button
                onClick={() => setMarketingType("internal")}
                className={`h-11 font-semibold text-sm rounded-xl transition-all shadow-lg ${
                  marketingType === "internal"
                    ? "bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white border-2 border-purple-400 shadow-purple-500/50"
                    : "bg-black/60 border-2 border-purple-500/40 text-purple-200 hover:bg-purple-500/20 hover:border-purple-400/60"
                }`}
              >
                Internal Marketing
              </Button>
              <Button
                onClick={() => setMarketingType("external")}
                className={`h-11 font-semibold text-sm rounded-xl transition-all shadow-lg ${
                  marketingType === "external"
                    ? "bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white border-2 border-purple-400 shadow-purple-500/50"
                    : "bg-black/60 border-2 border-purple-500/40 text-purple-200 hover:bg-purple-500/20 hover:border-purple-400/60"
                }`}
              >
                External Marketing
              </Button>
            </div>
          </div>

          {/* Conditional Fields Based on Marketing Type */}
          {marketingType === "internal" && (
            <div className="space-y-4 pt-5 border-t-2 border-purple-500/30 mt-4">
              {/* Duration */}
              <div className="space-y-2">
                <Label htmlFor="duration" className="text-purple-100 font-semibold text-sm">Duration (seconds)</Label>
                <Input
                  id="duration"
                  type="number"
                  placeholder="e.g., 120"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="h-10 bg-black/50 border-2 border-purple-500/40 text-slate-100 placeholder-purple-300/50 focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 rounded-xl transition-all"
                />
                <p className="text-xs text-purple-300/60 mt-1">
                  Specify the target duration for the podcast episode.
                </p>
              </div>

              {/* Add-On */}
              <div className="space-y-2">
                <Label className="text-purple-100 font-semibold text-sm">Add-On Files</Label>
                <input
                  type="file"
                  ref={addOnInputRef}
                  onChange={handleAddOnFileChange}
                  multiple
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => addOnInputRef.current?.click()}
                  className="h-10 bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 hover:from-green-600 hover:to-emerald-700 rounded-xl font-medium text-sm shadow-lg hover:shadow-green-500/30 transition-all"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
                {addOnFiles.length > 0 && (
                  <div className="space-y-2 mt-3">
                    {addOnFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2">
                        <span className="text-xs text-purple-200 truncate flex-1">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => removeAddOnFile(index)}
                          className="ml-2 text-purple-300 hover:text-white transition-colors"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-xs text-purple-300/60 mt-1">
                  Upload optional add-ons (e.g., PI, disclaimers, regional variants).
                </p>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button 
                  onClick={handleFormSubmit}
                  disabled={isSubmitting}
                  className="h-11 bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white hover:opacity-90 font-semibold text-sm px-8 py-2 w-full sm:w-auto rounded-xl shadow-lg shadow-purple-500/30 transition-all hover:shadow-purple-500/50 disabled:opacity-50"
                >
                  {isSubmitting ? "Submitting..." : "Generate Podcast"}
                </Button>
              </div>
            </div>
          )}

          {marketingType === "external" && (
            <div className="space-y-4 pt-5 border-t-2 border-purple-500/30 mt-4">
              {/* Demand Intake */}
              <div className="space-y-2">
                <Label className="text-purple-100 font-semibold text-sm">Demand Intake</Label>
                <input
                  type="file"
                  ref={demandIntakeInputRef}
                  onChange={handleDemandIntakeFileChange}
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                />
                <div className="flex flex-col sm:flex-row items-start gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => demandIntakeInputRef.current?.click()}
                    className="h-10 bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 hover:from-green-600 hover:to-emerald-700 rounded-xl font-medium text-sm shadow-lg hover:shadow-green-500/30 transition-all"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Choose File
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-10 text-purple-200 hover:text-white hover:bg-purple-500/20 border-2 border-purple-400/50 rounded-xl px-3 font-medium text-xs transition-all"
                  >
                    <Download className="h-3.5 w-3.5 mr-1.5" />
                    Download Sample Template
                  </Button>
                </div>
                {demandIntakeFile && (
                  <div className="flex items-center justify-between bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2 mt-2">
                    <span className="text-xs text-purple-200 truncate flex-1">{demandIntakeFile.name}</span>
                    <button
                      type="button"
                      onClick={() => setDemandIntakeFile(null)}
                      className="ml-2 text-purple-300 hover:text-white transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
                <p className="text-xs text-purple-300/60 mt-1">
                  Upload the MLR-approved brief (PDF/Doc).
                </p>
              </div>

              {/* Add-On */}
              <div className="space-y-2">
                <Label className="text-purple-100 font-semibold text-sm">Add-On Files</Label>
                <input
                  type="file"
                  ref={addOnInputRef}
                  onChange={handleAddOnFileChange}
                  multiple
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => addOnInputRef.current?.click()}
                  className="h-10 bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 hover:from-green-600 hover:to-emerald-700 rounded-xl font-medium text-sm shadow-lg hover:shadow-green-500/30 transition-all"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose File
                </Button>
                {addOnFiles.length > 0 && (
                  <div className="space-y-2 mt-3">
                    {addOnFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2">
                        <span className="text-xs text-purple-200 truncate flex-1">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => removeAddOnFile(index)}
                          className="ml-2 text-purple-300 hover:text-white transition-colors"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-xs text-purple-300/60 mt-1">
                  Upload optional add-ons (e.g., PI, disclaimers, regional variants).
                </p>
              </div>

              {/* Custom Prompt */}
              <div className="space-y-2">
                <div className="flex items-center justify-between mb-1">
                  <Label htmlFor="customPrompt" className="text-purple-100 font-semibold text-sm">Custom Prompt</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowSamplePrompt(!showSamplePrompt)}
                    className="h-9 text-purple-200 hover:text-white hover:bg-purple-500/20 border-2 border-purple-400/50 rounded-xl px-3 font-medium text-xs transition-all"
                  >
                    <FileText className="h-3.5 w-3.5 mr-1.5" />
                    Sample Prompt
                  </Button>
                </div>
                <Textarea
                  id="customPrompt"
                  placeholder="Paste or write specific instructions for EVA to follow."
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  rows={4}
                  className="bg-black/50 border-2 border-purple-500/40 text-slate-100 text-sm placeholder-purple-300/50 focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 rounded-xl transition-all"
                />
                <p className="text-xs text-purple-300/60 mt-1">
                  This prompt refines style, emphasis, and structure. Leave blank to use defaults.
                </p>
              </div>

              {/* Sample Prompt Cards */}
              {showSamplePrompt && (
                <div className="space-y-3">
                  {samplePromptOptions.map((option, index) => (
                    <div
                      key={index}
                      className="rounded-2xl border-2 border-purple-500/30 bg-gradient-to-br from-purple-500/10 to-fuchsia-500/5 p-4 space-y-2 backdrop-blur-sm"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-purple-100 text-sm">Sample Prompt ({option.title})</h4>
                        <Button
                          size="sm"
                          onClick={() => handleUseSamplePrompt(option.content)}
                          className="h-9 bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white hover:opacity-90 rounded-xl font-medium text-xs shadow-lg transition-all"
                        >
                          Use This
                        </Button>
                      </div>
                      <p className="text-xs text-purple-200/80 leading-relaxed">
                        {option.content}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Submit Button */}
              <div className="pt-4">
                <Button 
                  onClick={handleFormSubmit}
                  disabled={isSubmitting}
                  className="h-11 bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white hover:opacity-90 font-semibold text-sm px-8 py-2 w-full sm:w-auto rounded-xl shadow-lg shadow-purple-500/30 transition-all hover:shadow-purple-500/50 disabled:opacity-50"
                >
                  {isSubmitting ? "Submitting..." : "Generate Podcast"}
                </Button>
              </div>
            </div>
          )}

          {/* Clear Form Button - Always Visible */}
          {marketingType && (
            <div className="pt-5 border-t-2 border-purple-500/30 mt-5">
              <Button 
                variant="ghost"
                onClick={handleClearForm}
                className="h-10 text-purple-200 hover:text-white hover:bg-purple-500/20 font-medium text-sm rounded-xl px-5 transition-all"
              >
                Clear Form
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }