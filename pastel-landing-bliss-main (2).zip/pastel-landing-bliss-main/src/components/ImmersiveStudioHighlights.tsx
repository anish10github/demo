import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import channelIntelligenceImg from "@/assets/channel-intelligence.png";
import therapyIntelligenceImg from "@/assets/therapy-intelligence.png";
import persona1Img from "@/assets/persona-1.png";
import persona2Img from "@/assets/persona-2.png";
import persona3Img from "@/assets/persona-3.png";

/**
 * Immersive Studio Highlights
 * - 3D center-focus carousel (design unchanged)
 * - 4 cards
 * - Clicking a card opens a "mini landing page" popup
 *   sized like a PPT slide (~16:9) and ~3× the card size.
 * - Popup includes full content text + media slots.
 */

type Highlight = {
  title: string;
  description: string; // short 1-liner under the card
  gradient: string;
  image: string; // card image
  modal: {
    heading: string;
    blurb: string;
    sections: Array<
      | {
          type: "media-row"; // two side-by-side media frames
          left: { mediaType: "video" | "image"; src?: string; poster?: string; caption?: string };
          right: { mediaType: "video" | "image"; src?: string; poster?: string; caption?: string };
        }
      | {
          type: "media-single";
          media: { mediaType: "video" | "image"; src?: string; poster?: string; caption?: string };
        }
      | {
          type: "media-with-image";
          image: { src: string; caption: string };
          video: { src?: string; poster?: string };
        }
      | {
          type: "bullets";
          title?: string;
          items: string[];
        }
      | {
          type: "stats";
          items: Array<{ title: string; text: string }>;
        }
      | {
          type: "two-column";
          leftTitle: string;
          rightTitle: string;
          leftItems: string[];
          rightItems: string[];
        }
      | {
          type: "code";
          title: string;
          code: string;
        }
    >;
  };
};

const CARD_W_REM = 20; // tailwind w-80 ≈ 20rem
const CARD_H_REM = 24; // tailwind h-96 ≈ 24rem

const ImmersiveStudioHighlights = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  // Modal state
  const [isModalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState<Highlight | null>(null);

  // --- CARDS WITH FULL POPUP CONTENT (reordered) ---
  const highlights: Highlight[] = [
    {
      title: "Human Avatar Motion Capture",
      description: "Capture real gestures & expressions and map them to lifelike avatars.",
      gradient: "from-blue-200 to-blue-100",
      image:
        "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/Ed5QNGzMotZOiGLR2HRhAuIBRwgNrFXXrUMyp9qUVrOFjg?download=1",
      modal: {
        heading: "Gen AI Animated Videos Workflow — Lifelike Motion Capture for Human Avatars",
        blurb:
          "Tracks human movements (face, hands, and body), maps them onto digital avatars with precision, and delivers natural animations. Supports foundational actions (counting) and scales to complex gestures.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EanzVTvs5G5DieByip8qcG4BNXOpF9nvvsMa7hDlhQebRQ?download=1",
              caption: "Driving Motion Video",
            },
            right: {
              mediaType: "image",
              src: "https://indegene123-my.sharepoint.com/personal/anish_m_indegene_com/Documents/source%20image.png?ga=1",
              caption: "Source Image",
            },
          },
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/ESHnKZ8Y-TNEvWB344X412YBkXuqC0QfuohudXuE5XNg9Q?download=1",
              caption: "Motion output",
            },
          },
          {
            type: "bullets",
            title: "What it does:",
            items: [
              "Tracks real human movements, including facial expressions, gestures, and body language.",
              "Maps captured motions onto avatars from recorded sessions with precision.",
              "Delivers natural, lifelike animations that reflect authentic human behavior.",
              "Supports foundational actions like counting and waving, with flexibility for more complex gestures.",
            ],
          },
          {
            type: "stats",
            items: [
              { title: "Cost Efficiency", text: "Reduces costs by up to 57%." },
              { title: "Elimination of Reshoots", text: "Cuts rework and reshoot time by 30–50%." },
              { title: "Accelerated Timelines", text: "Speeds up content production by 2–3×." },
              { title: "Asset Reusability", text: "70–80% of avatar motions reusable across videos." },
            ],
          },
        ],
      },
    },
    {
      title: "Outfit and Style Adaptation",
      description: "Switch compliant looks & brand-aligned styles in seconds.",
      gradient: "from-pink-200 to-pink-100",
      image:
        "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EaVcwTaV2-pJr6USMJVA-i0BnKYGT62B_3tpQZB9Bqp_XA?download=1",
      modal: {
        heading: "Outfit and Style Adaptation",
        blurb:
          "Apply pharma-appropriate attire and brand-aligned styling to avatars, maintaining a professional, compliant presentation with strict adherence to visual and ethical guardrails.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EWr8vTWW0rRAujTmT-sLGY0BAoEfRBci4-prLzfY8WmjeQ?download=1",
              caption: "Source Video",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EWphetjud4RNiq9ESyQyUwYBklc89BWlOw2iEYSpl_d4UA?download=1",
              caption: "Suit Outfit",
            },
          },
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EcM-khXSHBJLiTevKeeaStsBM1XVPTcuF0GWAWGoTJUC2g?download=1",
              caption: "Lab Coat Outfit",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              "Pharma-compliant wardrobe presets (e.g., lab coat, formal business wear).",
              "Brand-safe color palettes and accessories; no unauthorized logos.",
              "Region-level validations for attire norms and cultural appropriateness.",
              "Pose-neutral, professional presentation for medical/scientific contexts.",
            ],
          },
        ],
      },
    },
    {
      title: "Built-In Pharma Guardrails",
      description: "Generate safe, compliant visuals with embedded controls.",
      gradient: "from-blue-200 to-cyan-100",
      image:
        "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EbPSFtYFriBErolj5jXbOz8BJJjdOB7uJQkq056jxqe8yw?download=1",
      modal: {
        heading: "Confidence in Every Frame: Gen-AI Video Creation with Built-In Pharma Guardrails",
        blurb:
          "Visual guardrails enforce attire, branding, and scene constraints. Outputs remain within medical, legal, and regulatory guidelines while preserving realism and clarity.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EZBuXtUYk_1Pi8muZpmj82QB1kYpX59igGeDvcFNJSJsiw?download=1",
              caption: "Without Guardrails",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EVXIBr3K3JtMttwfXWRTHcMBsytW0CSw8mliWyeLEAOzZg?download=1",
              caption: "Guardrails Applied",
            },
          },
          {
            type: "two-column",
            leftTitle: "Prompt (example):",
            rightTitle: "Guardrail outcomes:",
            leftItems: ['"A doctor wearing a stethoscope standing in a hospital, smiling."'],
            rightItems: [
              "Medical-appropriate attire enforced (e.g., lab coat allowed; casual wear blocked).",
              "No real hospital names/logos; brand safety + restricted trademarks blocked.",
              "Neutral, professional expression and pose validation.",
              "Scene set to generic medical office; compliant background details.",
            ],
          },
          {
            type: "code",
            title: "Guardrail policy (illustrative schema):",
            code: `{
  "avatar": { "gender": "male", "age_range": "30-40" },
  "attire": { "lab_coat": true, "stethoscope": true, "medically_appropriate": true },
  "expression": "neutral",
  "pose": "standing or seated in a relaxed professional posture",
  "environment": { "setting": "doctor's office", "lighting": "bright" },
  "background": { "type": "generic medical office" },
  "branding": "none",
  "visual_guidelines": {
    "realistic_restrictions": ["no_real_hospitals_or_clinics"],
    "no_restricted_trademarks": true
  },
  "attire_validation": true,
  "background_realism_permissioned": false
}`,
          },
        ],
      },
    },
    {
      title: "Element Animation",
      description: "Animate accurate scientific visuals from text or image prompts.",
      gradient: "from-indigo-200 to-blue-100",
      image:
        "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EQnBqi9BUvpNicuw9cmUclAB_MuoJjEmrxNyUCBrDq7uZA?download=1",
      modal: {
        heading: "Gen AI Animated Videos — Elemental Animation",
        blurb:
          "Generative AI creates accurate scientific visuals from text or image prompts, animates interactions and mechanisms, and makes complex medical concepts engaging and easy to understand.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/Ee0KmC446FxOqMAISz3wPJ0B83_08i8YD6pn4uhLkvzD_A?download=1",
              caption: "An Inside View of Blood Vessels",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/Eccgg2LOwIFDhf-7IaQaOTMBoQeUVe6AoH2EUR1uCs6fTw?download=1",
              caption: "Fat Deposit on Skin",
            },
          },
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EWpdtQhvU3REmg6aOSxBLA8BVxvqPbXUTfHNKi5o962ufw?download=1",
              caption: "A Brain Responsive Pattern",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EUE9UIf_WfNLl8TJ-lsrkBwBJMkPgUj8g00XOIfyakYNkA?download=1",
              caption: "Microbial Movements",
            },
          },
          {
            type: "bullets",
            title: "What it does:",
            items: [
              "Generative AI creates accurate scientific visuals from text or image prompts.",
              "Animates visuals to show movement, interaction, and functionality.",
              "Makes complex medical concepts engaging and easy to understand.",
            ],
          },
          {
            type: "stats",
            items: [
              {
                title: "Faster Content Creation",
                text: "Accelerate production with AI-driven visuals and motion.",
              },
              {
                title: "Scientific Accuracy",
                text: "Ground imagery in medically appropriate visual rules.",
              },
              {
                title: "Enhanced Understanding",
                text: "Clarify mechanisms with motion, interaction, and zooms.",
              },
              {
                title: "Engagement Boost",
                text: "Bring complex topics to life with cinematic animation.",
              },
            ],
          },
        ],
      },
    },
    {
      title: "Audience Intelligence",
      description: "Capture target personas and generate personalized, insight-driven content.",
      gradient: "from-purple-200 to-violet-100",
      image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=300&fit=crop",
      modal: {
        heading: "Audience Intelligence",
        blurb:
          "Utilize personas to create medically accurate, impactful videos that communicate key therapy messages and connect with healthcare professionals and patients.",
        sections: [
          {
            type: "media-with-image",
            image: {
              src: "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EWweuifNwSxLoImDivF6R98B9EGHHb59IZ9j4jENjQa4sg?download=1",
              caption:
                "Chris, is a successful entrepreneur living a fast-paced, luxurious life. Confident and driven, he often neglects his health, postponing check-ups despite his wife’s reminders. He represents men who deny potential health risks — a reminder that even success means little without health. Early screening keeps you in control. ",
            },
            video: {
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EQAuOMbGTjNLtXEivneRHIEBNnYWpOE5uSjiz27oWP7JKw?download=1",
            },
          },
          {
            type: "media-with-image",
            image: {
              src: "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EbO8DhmS86hCtm8dC3O8IjkBIUzg0_drPs4ioKBciZ-VeQ?download=1",
              caption:
                "Nick, a hardworking restaurant owner from Phoenix, lives a modest life centered around family, good food, and weekend BBQs. Though at high risk for prostate cancer, he long ignored health warnings — until he finally chose to face his fears and get screened. He represents men who delay check-ups despite the signs but ultimately take control of their health. Regular screenings safeguard not just his well-being, but his family and future.",
            },
            video: {
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EdTb7rT4entChboorlFuX-sBFTWhLMeX0kURuo_zlsHM6w?download=1",
            },
          },
          {
            type: "media-with-image",
            image: {
              src: "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EQ9pN2iLYRlIoKTLZQVgCQkBfhfsGN2IhYvZ8NiGtuZ6lA?download=1",
              caption:
                "Xander, an elderly retired man with a family history of prostate cancer, lives a simple, family-oriented life. Initially hesitant about screening, he eventually chooses awareness over fear. He represents those who become proactive through education — proving that awareness empowers timely action and protects health.",
            },
            video: {
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/Ef8zXgyzesRNsRou8YEwnK0BC7ZFglOWzEBYYakWeLILrQ?download=1",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              " Capture and analyze detailed patient and healthcare professional personas, including demographics, treatment preferences, and engagement behaviors.",
              " Develop scientifically accurate, therapy-specific content aligned with audience insights to ensure medical reliability and relevance.",
              " Deliver educational and awareness-driven materials that effectively communicate key clinical messages to patients and healthcare professionals.",
              " Ensure all content adheres to regulatory guidelines, maintaining ethical and compliant communication standards.",
            ],
          },
        ],
      },
    },
    {
      title: "Podcast Evolution",
      description: "Elevate your podcasts with advanced visuals, precise editing, and immersive storytelling.",
      gradient: "from-cyan-200 to-sky-100",
      image: "https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=400&h=300&fit=crop",
      modal: {
        heading: "Podcast Evolution",
        blurb:
          "Transform your podcast into a dynamic, engaging experience. Achieve perfect lip-sync, natural host movements, and seamless transitions for professional, story-driven content.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EbseDW6yCDpHp_UkpeM6Vu4BVedDTBKxv4HkkjkgsUKn3w?download=1",
              caption: "Static Frame Podcast",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EcWEoZi4dXpEjd-yfV-QLg8Bnfk8I5JHAYID0iEKgtCNqA?download=1",
              caption: "Pharma Conversations with Camera Angels to the respective speakers",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              "Real-Life Podcast Cuts & Transitions",
              "Dynamic Dual-Host 45°, 90°, 135° Angle Layout",
              "Perfect Lip-Sync Accuracy",
              "Enhanced Visual Storytelling",
              "Natural Hand & Head Motions",
              "Seamless Conversation Loop",
              "Engaging Eye-Line Alignment",
            ],
          },
        ],
      },
    },
    {
      title: "Style Intelligence",
      description: "Transform videos through artistic, cinematic, and emotionally rich visual styles.",
      gradient: "from-fuchsia-200 to-purple-100",
      image:
        "https://indegene123-my.sharepoint.com/:i:/g/personal/anish_m_indegene_com/EUr3aGCBDspFqft1DtrvscsBrUOb6995esLJ3IcdoqAjgA?download=1",
      modal: {
        heading: "Style Intelligence",
        blurb:
          "Simplify complex concepts through engaging, story-driven visuals. The style intelligence engine reimagines videos with seamless artistic adaptation, emotion-rich storytelling, and creative precision—tailored to brand, message, and medium.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/ESmrhuO0K9dIinArytFvu60BVmQb1ywZSVagzgCXN1RTKQ?download=1",
              caption: "Source Video",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/ERX_HmtqL4lImJ7qMokOAyoB4pAuol3f8cZYh1rkERYuqw?download=1",
              caption: "Ghibli Style",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              " Applies diverse artistic styles such as Ghibli, Lo-Fi, Cinematic, and Vaporwave.",
              " Seamless artistic style adaptation for consistent visual storytelling.",
              " Emotion-rich transformation to enhance viewer connection and engagement.",
              " Scalable creative reimagination powered by AI for multiple formats.",
              " Precision video transformation maintaining brand integrity and visual clarity.",
            ],
          },
          {
            type: "bullets",
            title: "Available Styles:",
            items: [
              "Illustration • Dreamy • Modern • Cinematic • Chrome • Pinata • Ghibli • Lo-Fi • Vaporwave • Collage • Pastel Baroque • Pixel • Centered Subject • Rule of Thirds • Symmetrical • Disposable Film • Monotone • Heavy Grain Film • VHS • Portrait Photography • Product Photography • Relaxed • In Motion • Surreal Anatomy • Theatre Marquee • Neon Sign • Balloon • Scanner • Static Hologram",
            ],
          },
        ],
      },
    },
    {
      title: "Channel Intelligence",
      description: "Automatically adapt videos to the optimal aspect ratio for every platform.",
      gradient: "from-orange-200 to-amber-100",
      image: channelIntelligenceImg,
      modal: {
        heading: "Channel Intelligence",
        blurb:
          "Transform original video content into platform-specific aspect ratios while preserving all visual assets and ensuring consistent, accurate messaging.",
        sections: [
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EUQHWyepOZNPs_j6bAsv-bcBJsQ2_f_QF7dY4ZNa_3ogPg?download=1",
              caption: "Facebook and LinkedIn",
            },
          },
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/ETl4_z6IR3BEocxON0iDvtEB4JMRo04V8dzr-13LP22iig?download=1",
              caption: "Instagram",
            },
          },
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EVKeNKhTiMpKtSDW0s4bzZUBIukqinY0qZD4lxZMtJDs7Q?download=1",
              caption: "YouTube",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              " Convert video content into multiple platform-specific aspect ratios while safeguarding all core assets and therapeutic messaging.",
              " Preserve visual clarity, scientific accuracy, and professional presentation across digital channels.",
              " Retain and highlight critical therapy insights and key content elements during adaptation.",
              " Deliver fully compliant, ready-to-use content efficiently, minimizing manual intervention and ensuring consistent quality.",
            ],
          },
        ],
      },
    },
    {
      title: "Therapy Intelligence",
      description: "Create therapy-focused, animated content tailored to specific therapeutic areas.",
      gradient: "from-rose-200 to-red-100",
      image: therapyIntelligenceImg,
      modal: {
        heading: "Therapy Intelligence",
        blurb:
          "Develop scientifically accurate, visually engaging content tailored to specific therapeutic areas. Utilize audience insights and clinical data to create mechanism-of-action animations and educational visuals that simplify complex scientific concepts while ensuring compliance with medical and regulatory standards.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EXW4q391z2xNpe3Qpx7scpsBvK7v29hO6H8wlykI9nCQcg?download=1",
              caption: "Blood Cancer Awareness",
            },
            right: {
              mediaType: "video",
              src: "https://indegene123-my.sharepoint.com/:v:/g/personal/anish_m_indegene_com/EbkuNNR8h-hOtShzxMZBQIAB-O8D_9vHouP6LM56dqq2cg?download=1",
              caption: "Treatment Approach",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              " Generates content tailored to specific therapeutic areas and treatment domains.",
              " Integrates therapy-focused audience insights to engage clinicians, patients, and healthcare professionals effectively.",
              " Uses dynamic animations to simplify complex therapy mechanisms and enhance understanding.",
              " Supports multi-format content creation.",
            ],
          },
        ],
      },
    },
    {
      title: "Global to Local Intelligence",
      description: "Adapt global content for local audiences with precision and cultural nuance.",
      gradient: "from-emerald-200 to-teal-100",
      image: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=400&h=300&fit=crop",
      modal: {
        heading: "Global to Local Intelligence",
        blurb:
          "Transforming content into culturally aware videos and scripts that resonate across regions, while maintaining brand consistency, accuracy, and professional standards.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "video",
              src: "",
              caption: "Spanish",
            },
            right: {
              mediaType: "video",
              src: "",
              caption: "French",
            },
          },
          {
            type: "media-single",
            media: {
              mediaType: "video",
              src: "",
              caption: "Chinese",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              " Transform standardized medical scripts and visuals into region-specific, culturally relevant formats.",
              " Align tone, imagery, and messaging with local healthcare practices, patient expectations, and regulatory requirements.",
              " Maintain global brand consistency while enabling market-tailored communication.",
              " Embed compliance and quality checks to ensure scientific accuracy and ethical standards.",
              " Enable efficient, multi-market deployment without compromising speed or precision.",
            ],
          },
        ],
      },
    },
    {
      title: "Cinematic Intelligence",
      description: "Bring your pharma videos to life with immersive mirror transitions and reflective storytelling.",
      gradient: "from-violet-200 to-indigo-100",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop",
      modal: {
        heading: "Cinematic Intelligence",
        blurb:
          "Transform standard pharma videos into visually stunning experiences. Achieve seamless mirror reveals, synchronized reflections, and dynamic scene transitions that captivate your audience.",
        sections: [
          {
            type: "media-row",
            left: {
              mediaType: "image",
              src: "",
              caption: "Source Image",
            },
            right: {
              mediaType: "video",
              src: "",
              caption: "Mirror Effect",
            },
          },
          {
            type: "bullets",
            title: "Capabilities:",
            items: [
              "Seamless Mirror Transitions",
              "Enhanced Visual Storytelling",
              "Dynamic Reflection Reveals",
            ],
          },
        ],
      },
    },
  ];

  // intersection reveal
  useEffect(() => {
    const obs = new IntersectionObserver((entries) => entries.forEach((e) => e.isIntersecting && setIsVisible(true)), {
      threshold: 0.3,
    });
    if (sectionRef.current) obs.observe(sectionRef.current);
    return () => obs.disconnect();
  }, []);

  // keyboard nav + modal esc
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isModalOpen) {
        if (e.key === "Escape") setModalOpen(false);
        return;
      }
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        navigateTo(activeIndex - 1);
      }
      if (e.key === "ArrowRight") {
        e.preventDefault();
        navigateTo(activeIndex + 1);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [activeIndex, isModalOpen]);

  const navigateTo = (i: number) => {
    const n = i < 0 ? highlights.length - 1 : i >= highlights.length ? 0 : i;
    setActiveIndex(n);
  };

  const openModal = (h: Highlight) => {
    setSelected(h);
    setModalOpen(true);
  };

  // 3D transforms
  const getCardStyle = (index: number) => {
    const diff = index - activeIndex;
    const abs = Math.abs(diff);
    if (abs === 0) {
      return {
        transform: "translateX(0) translateZ(0) rotateY(0deg) scale(1.1)",
        opacity: 1,
        zIndex: 10,
      };
    }
    const dir = diff > 0 ? 1 : -1;
    if (abs === 1) {
      return {
        transform: `translateX(${dir * 240}px) translateZ(-50px) rotateY(${-dir * 8}deg) scale(0.85)`,
        opacity: 1,
        zIndex: 5,
      };
    }
    return {
      transform: `translateX(${dir * 320}px) translateZ(-100px) rotateY(${-dir * 12}deg) scale(0.7)`,
      opacity: 1,
      zIndex: 1,
    };
  };

  return (
    <section
      id="Immersivestudiohighlights"
      ref={sectionRef}
      className="py-12 px-4 relative overflow-hidden bg-gradient-to-b from-background via-background/95 to-background"
    >
      {/* animated background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 1200 400">
          <defs>
            <linearGradient id="highlightGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
              <stop offset="50%" stopColor="hsl(var(--accent))" stopOpacity="0.7" />
              <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
            </linearGradient>
          </defs>
          <path
            d="M 0 200 Q 300 150 600 200 T 1200 200"
            stroke="url(#highlightGradient)"
            strokeWidth="3"
            fill="none"
            style={{ strokeDasharray: "15 10" }}
          />
        </svg>
      </div>

      <div className="container mx-auto relative z-10">
        {/* header */}
        <div
          className={`text-center mb-8 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gradient-pink-blue mb-4 relative">
            Immersive Studio Highlights
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-2 w-24 h-0.5 bg-gradient-to-r from-primary to-accent" />
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our next-generation Gen AI capabilities tailored for pharma content creation.
          </p>
        </div>

        {/* side nav arrows */}
        <div className="relative">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigateTo(activeIndex - 1)}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-blue-500 border-none text-white hover:from-pink-600 hover:to-blue-600 focus:ring-2 focus:ring-primary z-20 shadow-lg"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigateTo(activeIndex + 1)}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-blue-500 border-none text-white hover:from-pink-600 hover:to-blue-600 focus:ring-2 focus:ring-primary z-20 shadow-lg"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>

          {/* carousel stage */}
          <div
            ref={stageRef}
            className="relative h-[500px] flex items-center justify-center"
            style={{ perspective: "1200px", perspectiveOrigin: "center center" }}
          >
            {highlights.map((h, i) => {
              const style = getCardStyle(i);
              return (
                <div
                  key={h.title}
                  className="absolute w-80 h-96 cursor-pointer transition-all duration-500 group"
                  style={{
                    ...style,
                    transitionProperty: "transform, opacity, filter",
                    transitionTimingFunction: "cubic-bezier(0.34, 1.56, 0.64, 1)",
                  }}
                  onClick={() => {
                    setActiveIndex(i);
                    openModal(h);
                  }}
                >
                  <div
                    className={`h-full rounded-2xl p-6 relative hover:scale-105 hover:shadow-2xl transition-all duration-300 bg-gradient-to-br ${h.gradient} shadow-lg border border-border`}
                  >
                    {i === activeIndex && (
                      <div className="absolute -top-2 -right-2 w-4 h-4 bg-primary rounded-full shadow-lg" />
                    )}
                    <div className="relative mb-6 mt-4">
                      <div className="aspect-video w-full rounded-2xl overflow-hidden border border-border group-hover:border-primary transition-colors duration-300 shadow-md">
                        {h.image ? (
                          <img
                            src={h.image}
                            alt={h.title}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          />
                        ) : (
                          <div className="w-full h-full bg-muted flex items-center justify-center relative overflow-hidden">
                            <div className={`absolute inset-0 bg-gradient-to-br ${h.gradient}`} />
                            <div className="w-14 h-14 rounded-full bg-background shadow-xl flex items-center justify-center border border-border">
                              <div className="w-0 h-0 border-l-[16px] border-l-foreground border-y-[10px] border-y-transparent ml-1" />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-center">
                      <h3 className="text-xl font-bold mb-2 text-foreground">{h.title}</h3>
                      <p className="text-sm text-black leading-relaxed">{h.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* MODAL */}
        {isModalOpen && selected && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center">
            <div className="absolute inset-0 bg-black/60" onClick={() => setModalOpen(false)} />
            <div
              className="relative bg-white rounded-2xl shadow-2xl overflow-hidden"
              style={{ width: "min(60rem, 92vw)", aspectRatio: "16 / 9", maxHeight: "90vh" }}
              role="dialog"
              aria-modal="true"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b bg-blue-50">
                <h3 className="text-lg md:text-2xl font-bold text-blue-800">{selected.modal.heading}</h3>
                <button
                  onClick={() => setModalOpen(false)}
                  className="p-2 rounded-full hover:bg-black/10"
                  aria-label="Close"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="p-6 overflow-auto h-[calc(100%-64px)]">
                <p className="text-sm md:text-base text-slate-700 mb-6">{selected.modal.blurb}</p>
                {selected.modal.sections.map((section, idx) => {
                  // Special handling for Audience Intelligence: combine 3 media-with-image sections into one row
                  if (section.type === "media-with-image" && selected.title === "Audience Intelligence" && idx === 0) {
                    const secondSection = selected.modal.sections[idx + 1];
                    const thirdSection = selected.modal.sections[idx + 2];
                    if (
                      secondSection &&
                      secondSection.type === "media-with-image" &&
                      thirdSection &&
                      thirdSection.type === "media-with-image"
                    ) {
                      // Render all 3 image-video pairs in one row
                      return (
                        <div key={idx} className="flex gap-3 mb-6 justify-center items-start">
                          {/* First persona */}
                          <div className="flex flex-col items-center max-w-[280px]">
                            <div className="mb-2 w-20 h-20 rounded-full overflow-hidden border-2 border-purple-500 shadow-lg">
                              <img
                                src={section.image.src}
                                alt="Chris"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <p className="text-sm font-bold text-gray-600 mb-2">CHRIS</p>
                            <p className="text-xs text-gray-700 mb-3 text-center leading-relaxed px-2">
                              Chris, is a successful entrepreneur living a fast-paced, luxurious life. Confident and driven, he often neglects his health, postponing check-ups despite his wife's reminders. He represents men who deny potential health risks — a reminder that even success means little without health. Early screening keeps you in control.
                            </p>
                            <div className="h-[140px] w-full rounded-xl border-2 border-purple-500 shadow-lg overflow-hidden bg-black">
                              <video
                                src={section.video.src}
                                poster={section.video.poster}
                                controls
                                className="w-full h-full object-contain"
                              />
                            </div>
                          </div>
                          {/* Second persona */}
                          <div className="flex flex-col items-center max-w-[280px]">
                            <div className="mb-2 w-20 h-20 rounded-full overflow-hidden border-2 border-purple-500 shadow-lg">
                              <img
                                src={secondSection.image.src}
                                alt="Nick"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <p className="text-sm font-bold text-gray-600 mb-2">NICK</p>
                            <p className="text-xs text-gray-700 mb-3 text-center leading-relaxed px-2">
                              Nick, a hardworking restaurant owner from Phoenix, lives a modest life centered around family, good food, and weekend BBQs. Though at high risk for prostate cancer, he long ignored health warnings — until he finally chose to face his fears and get screened. He represents men who delay check-ups despite the signs but ultimately take control of their health. Regular screenings safeguard not just his well-being, but his family and future.
                            </p>
                            <div className="h-[140px] w-full rounded-xl border-2 border-purple-500 shadow-lg overflow-hidden bg-gray-100 flex items-center justify-center relative">
                              <span className="bg-purple-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                                Coming Soon
                              </span>
                            </div>
                          </div>
                          {/* Third persona */}
                          <div className="flex flex-col items-center max-w-[280px]">
                            <div className="mb-2 w-20 h-20 rounded-full overflow-hidden border-2 border-purple-500 shadow-lg">
                              <img
                                src={thirdSection.image.src}
                                alt="Xander"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <p className="text-sm font-bold text-gray-600 mb-2">XANDER</p>
                            <p className="text-xs text-gray-700 mb-3 text-center leading-relaxed px-2">
                              Xander, an elderly retired man with a family history of prostate cancer, lives a simple, family-oriented life. Initially hesitant about screening, he eventually chooses awareness over fear. He represents those who become proactive through education — proving that awareness empowers timely action and protects health.
                            </p>
                            <div className="h-[140px] w-full rounded-xl border-2 border-purple-500 shadow-lg overflow-hidden bg-black">
                              <video
                                src={thirdSection.video.src}
                                poster={thirdSection.video.poster}
                                controls
                                className="w-full h-full object-contain"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    }
                  }

                  // Skip media-with-image sections 2 and 3 for Audience Intelligence (already rendered in combined row)
                  if (
                    section.type === "media-with-image" &&
                    selected.title === "Audience Intelligence" &&
                    (idx === 1 || idx === 2)
                  ) {
                    return null;
                  }

                  // Special handling for Channel Intelligence: combine 3 media-single sections into one row
                  if (section.type === "media-single" && selected.title === "Channel Intelligence" && idx === 0) {
                    const secondSection = selected.modal.sections[idx + 1];
                    const thirdSection = selected.modal.sections[idx + 2];
                    if (
                      secondSection &&
                      secondSection.type === "media-single" &&
                      thirdSection &&
                      thirdSection.type === "media-single"
                    ) {
                      // Render all 3 videos in one row with mini sizes and different aspect ratios
                      return (
                        <div key={idx} className="flex gap-4 mb-6 justify-center items-start">
                          {/* First video: 1:1 aspect ratio */}
                          <div className="flex flex-col items-center">
                            <div className="h-[200px] aspect-square rounded-xl border-2 border-orange-500 shadow-lg overflow-hidden bg-black">
                              {section.media.mediaType === "video" ? (
                                <video
                                  src={section.media.src}
                                  poster={section.media.poster}
                                  controls
                                  className="w-full h-full object-contain"
                                />
                              ) : (
                                <img src={section.media.src} alt="" className="w-full h-full object-cover" />
                              )}
                            </div>
                            {section.media.caption && (
                              <p className="mt-2 text-center text-sm font-medium text-slate-700">
                                {section.media.caption}
                              </p>
                            )}
                          </div>
                          {/* Second video: 9:16 aspect ratio - slightly bigger */}
                          <div className="flex flex-col items-center">
                            <div className="h-[240px] aspect-[9/16] rounded-xl border-2 border-orange-500 shadow-lg overflow-hidden bg-black">
                              {secondSection.media.mediaType === "video" ? (
                                <video
                                  src={secondSection.media.src}
                                  poster={secondSection.media.poster}
                                  controls
                                  className="w-full h-full object-contain"
                                />
                              ) : (
                                <img src={secondSection.media.src} alt="" className="w-full h-full object-cover" />
                              )}
                            </div>
                            {secondSection.media.caption && (
                              <p className="mt-2 text-center text-sm font-medium text-slate-700">
                                {secondSection.media.caption}
                              </p>
                            )}
                          </div>
                          {/* Third video: 16:9 aspect ratio */}
                          <div className="flex flex-col items-center">
                            <div className="h-[200px] aspect-video rounded-xl border-2 border-orange-500 shadow-lg overflow-hidden bg-black">
                              {thirdSection.media.mediaType === "video" ? (
                                <video
                                  src={thirdSection.media.src}
                                  poster={thirdSection.media.poster}
                                  controls
                                  className="w-full h-full object-contain"
                                />
                              ) : (
                                <img src={thirdSection.media.src} alt="" className="w-full h-full object-cover" />
                              )}
                            </div>
                            {thirdSection.media.caption && (
                              <p className="mt-2 text-center text-sm font-medium text-slate-700">
                                {thirdSection.media.caption}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    }
                  }

                  // Skip media-single sections 2 and 3 for Channel Intelligence (already rendered in combined row)
                  if (
                    section.type === "media-single" &&
                    selected.title === "Channel Intelligence" &&
                    (idx === 1 || idx === 2)
                  ) {
                    return null;
                  }

                  if (section.type === "media-row") {
                    const isGlobalToLocal = selected.title === "Global to Local Intelligence";
                    return (
                      <div key={idx} className="grid md:grid-cols-2 gap-6 mb-6">
                        {[section.left, section.right].map((slot, i) => (
                          <div key={i} className="w-full">
                            <div className="aspect-video w-full rounded-xl border-2 border-pink-500 shadow-lg overflow-hidden bg-black relative">
                              {slot.mediaType === "video" ? (
                                <video
                                  src={slot.src}
                                  poster={slot.poster}
                                  controls
                                  className="w-full h-full object-contain"
                                />
                              ) : (
                                <img src={slot.src} alt={slot.caption || ""} className="w-full h-full object-cover" />
                              )}
                              {isGlobalToLocal && (
                                <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                                  Coming Soon
                                </div>
                              )}
                            </div>
                            {slot.caption && (
                              <p className="mt-2 text-center text-sm font-medium text-slate-700">{slot.caption}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    );
                  }
                  if (section.type === "media-single") {
                    const isGlobalToLocal = selected.title === "Global to Local Intelligence";
                    return (
                      <div key={idx} className="grid md:grid-cols-2 gap-6 mb-6">
                        <div className="w-full">
                          <div className="aspect-video w-full rounded-xl border-2 border-pink-500 shadow-lg overflow-hidden bg-black relative">
                            {section.media.mediaType === "video" ? (
                              <video
                                src={section.media.src}
                                poster={section.media.poster}
                                controls
                                className="w-full h-full object-contain"
                              />
                            ) : (
                              <img
                                src={section.media.src}
                                alt={section.media.caption || ""}
                                className="w-full h-full object-cover"
                              />
                            )}
                            {isGlobalToLocal && (
                              <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg">
                                Coming Soon
                              </div>
                            )}
                          </div>
                          {section.media.caption && (
                            <p className="mt-2 text-center text-sm font-medium text-slate-700">
                              {section.media.caption}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  }
                  if (section.type === "bullets") {
                    const isStyleIntelligence = selected.title === "Style Intelligence";
                    const isAvailableStyles = section.title === "Available Styles:";

                    if (isStyleIntelligence && isAvailableStyles) {
                      return (
                        <div key={idx} className="mb-6">
                          <h4 className="font-semibold mb-4 text-lg">{section.title}</h4>
                          <div className="p-6 rounded-2xl bg-gradient-to-br from-fuchsia-50 via-purple-50 to-pink-50 border-2 border-fuchsia-300 shadow-lg">
                            <div className="flex flex-wrap gap-2 items-center justify-center">
                              {section.items[0].split(" • ").map((style, i) => (
                                <span
                                  key={i}
                                  className="px-3 py-1.5 text-xs font-medium rounded-full bg-gradient-to-r from-fuchsia-500 to-purple-500 text-white shadow-md hover:shadow-lg hover:scale-105 transition-all cursor-default"
                                >
                                  {style}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div key={idx} className="mb-6">
                        {section.title && <h4 className="font-semibold mb-2">{section.title}</h4>}
                        <ul className="list-disc pl-5 space-y-1 text-sm md:text-base">
                          {section.items.map((it, i) => (
                            <li key={i}>{it}</li>
                          ))}
                        </ul>
                      </div>
                    );
                  }
                  if (section.type === "stats") {
                    return (
                      <div key={idx} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                        {section.items.map((s, i) => (
                          <div
                            key={i}
                            className="rounded-xl border border-slate-200 p-4 text-center shadow-sm bg-slate-50"
                          >
                            <div className="font-semibold">{s.title}</div>
                            <div className="text-sm text-slate-700 mt-1">{s.text}</div>
                          </div>
                        ))}
                      </div>
                    );
                  }
                  if (section.type === "two-column") {
                    return (
                      <div key={idx} className="grid md:grid-cols-2 gap-6 mb-6">
                        <div>
                          <h5 className="font-semibold mb-2">{section.leftTitle}</h5>
                          <ul className="list-disc pl-5 space-y-1 text-sm md:text-base">
                            {section.leftItems.map((it, i) => (
                              <li key={i}>{it}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h5 className="font-semibold mb-2">{section.rightTitle}</h5>
                          <ul className="list-disc pl-5 space-y-1 text-sm md:text-base">
                            {section.rightItems.map((it, i) => (
                              <li key={i}>{it}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    );
                  }
                  if (section.type === "code") {
                    return (
                      <div key={idx} className="mb-6">
                        <h5 className="font-semibold mb-2">{section.title}</h5>
                        <pre className="text-xs md:text-sm bg-slate-900 text-slate-100 p-4 rounded-xl overflow-auto">
                          {section.code}
                        </pre>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default ImmersiveStudioHighlights;
