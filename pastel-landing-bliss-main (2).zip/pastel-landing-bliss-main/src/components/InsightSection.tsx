import { Calendar, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const insights = [
  {
    id: 'ai-evolution-2025',
    title: 'The Evolution of AI in Content Creation: What 2025 Brings',
    excerpt: 'Exploring the latest trends in AI-powered content creation, from text generation to immersive video experiences.',
    publishDate: '2025-09-09'
  },
  {
    id: 'future-virtual-meetings',
    title: 'Beyond Video Calls: The Future of Virtual Meetings',
    excerpt: 'Virtual meetings are evolving beyond simple video calls. Discover how avatar technology is reshaping remote collaboration.',
    publishDate: '2025-09-09'
  },
  {
    id: 'voice-ai-healthcare',
    title: 'Voice AI in Healthcare: Transforming Patient Communication',
    excerpt: 'How voice AI technology is revolutionizing patient communication and creating more personalized healthcare experiences.',
    publishDate: '2025-09-09'
  }
];

const InsightSection = () => {
  return (
    <section id="insights" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-bold text-gradient-pink-blue mb-6">
            Latest Insights & Resources
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Stay informed with our latest thinking on technology, innovation, and industry best practices.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {insights.map((insight, index) => (
            <Link
              key={insight.id}
              to={`/insights/${insight.id}`}
              className="block fade-in group cursor-pointer"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <article className="bg-background border border-border rounded-lg shadow-sm hover:shadow-md transition-all duration-300 p-6 h-full">
                <h3 className="font-bold text-foreground mb-3 line-clamp-2 text-lg group-hover:text-primary transition-colors duration-200">
                  {insight.title}
                </h3>
                <p className="text-muted-foreground text-sm line-clamp-2 mb-4 leading-relaxed">
                  {insight.excerpt}
                </p>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(insight.publishDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <span className="text-xs font-medium">Read More</span>
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
              </article>
            </Link>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12 fade-in">
          <button className="inline-flex items-center text-primary hover:text-accent font-semibold transition-colors duration-200">
            View All Insights
            <ArrowRight className="w-4 h-4 ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default InsightSection;