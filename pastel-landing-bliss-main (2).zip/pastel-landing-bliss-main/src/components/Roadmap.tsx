import { useState } from 'react';

interface RoadmapProps {
  steps: string[];
  onStepClick: (index: number) => void;
}

const Roadmap = ({ steps, onStepClick }: RoadmapProps) => {
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);

  return (
    <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
      {steps.map((step, index) => (
        <div key={index} className="flex items-center">
          <div
            className={`
              relative px-4 py-2 rounded-full border transition-all duration-300 cursor-pointer
              bg-gradient-to-r from-violet-900/40 to-purple-900/40 
              border-violet-400/30 text-violet-200 hover:border-violet-400/60
              ${hoveredStep === index ? 'scale-105 shadow-lg shadow-violet-500/20' : ''}
            `}
            onClick={() => onStepClick(index)}
            onMouseEnter={() => setHoveredStep(index)}
            onMouseLeave={() => setHoveredStep(null)}
          >
            <span className="text-sm font-medium">{step}</span>
          </div>
          {index < steps.length - 1 && (
            <div className="mx-2 w-8 h-0.5 bg-gradient-to-r from-violet-400/40 to-purple-400/40" />
          )}
        </div>
      ))}
    </div>
  );
};

export default Roadmap;