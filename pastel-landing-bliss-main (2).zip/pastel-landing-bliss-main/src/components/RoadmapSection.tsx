import React, { useState } from "react";

type QuarterId = "Q2 2025" | "Q3 2025" | "Q4 2025" | "Future";

interface Quarter {
  id: QuarterId;
  label: string;
  color: string;
}

interface Item {
  id: string;
  quarter: QuarterId;
  title: string;
  desc: string;
}

const QUARTERS: Quarter[] = [
  { id: "Q2 2025", label: "Q2 2025", color: "#00C0F3" },
  { id: "Q3 2025", label: "Q3 2025", color: "#ED0677" },
  { id: "Q4 2025", label: "Q4 2025", color: "#034EA2" },
  { id: "Future",  label: "Future",  color: "#00C0A1" },
];

const ITEMS: Item[] = [
  // Q2 — Foundational
  { id: "m1", quarter: "Q2 2025", title: "Storyboard Development", desc: "Define scene flow, narrative scripts, and visual frameworks." },
  { id: "m2", quarter: "Q2 2025", title: "Prompt‑Driven Image Animation", desc: "Animate static visuals using prompts." },
  { id: "m3", quarter: "Q2 2025", title: "Text‑to‑Video Generation", desc: "Turn text prompts into finished videos in minutes." },
  { id: "m4", quarter: "Q2 2025", title: "Basic Voice‑Over & Music", desc: "Add narration and ambient soundtracks." },

  // Q3 — Advanced
  { id: "m5", quarter: "Q3 2025", title: "Multiple Visual Styles (15+)", desc: "Create Sketch, Realistic, or 3D videos." },
  { id: "m6", quarter: "Q3 2025", title: "Dynamic Motion & Brushing", desc: "Use 11 movement types to animate scenes." },
  { id: "m7", quarter: "Q3 2025", title: "Custom Angles & Lighting", desc: "Adjust camera perspectives and lighting." },
  { id: "m8", quarter: "Q3 2025", title: "Character Consistency", desc: "Keep avatars uniform across content." },
  { id: "m9", quarter: "Q3 2025", title: "AI Outfit", desc: "Vary the same avatar by geography, role, audience." },

  // Q4 — Cinematic (We are here)
  { id: "m10", quarter: "Q4 2025", title: "Context Precision", desc: "Scene‑aware generation adapts in real time." },
  { id: "m11", quarter: "Q4 2025", title: "Scene SFX & Ambience", desc: "Dynamic soundscapes enhance mood." },
  { id: "m12", quarter: "Q4 2025", title: "GenAI Background Animations", desc: "Contextual backgrounds matched to avatar content." },
  { id: "m13", quarter: "Q4 2025", title: "GenAI Element Animations", desc: "Graphic elements with smooth, context‑driven motion." },
  { id: "m14", quarter: "Q4 2025", title: "GenAI Visual Effects", desc: "Frame‑level VFX blending for cinematic detail." },
  { id: "m15", quarter: "Q4 2025", title: "Motion Transfer", desc: "Transfer realistic motion from reference video." },
  { id: "m16", quarter: "Q4 2025", title: "Motion Capture", desc: "Drive generation via performance & tracked reference." },

  // Future
  { id: "m31", quarter: "Future", title: "Trajectory Control", desc: "Precisely direct subject motion for natural movement." },
  { id: "m32", quarter: "Future", title: "Long‑Form GenAI Videos", desc: "Generate high‑quality videos up to ~60s from one prompt." },
  { id: "m33", quarter: "Future", title: "Agentic Video Production", desc: "Multi‑step, scalable workflows with minimal input." },
  { id: "m34", quarter: "Future", title: "Text → 3D Animation", desc: "Type prompts to drive character motion in 3D." },
];

const RoadmapSection: React.FC = () => {
  const [activeQuarter, setActiveQuarter] = useState<QuarterId>("Q4 2025");
  const [hoverItem, setHoverItem] = useState<string | null>(null);

  const getActiveQuarterIndex = () => QUARTERS.findIndex(q => q.id === activeQuarter);
  const itemsForQuarter = (quarterId: QuarterId) => ITEMS.filter(i => i.quarter === quarterId);

  return (
    <section id="roadmap" className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gradient mb-3">
            Immersive Studio Roadmap
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            From foundation to cinematic to future-ready video.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative mb-16">
          {/* Timeline line */}
          <div className="relative h-1 bg-slate-200 rounded-full mx-8">
            {/* Active indicator with smooth transition */}
            <div 
              className="absolute top-0 h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-500 ease-out"
              style={{
                left: `${(getActiveQuarterIndex() / (QUARTERS.length - 1)) * 100}%`,
                width: '8px',
                marginLeft: '-4px'
              }}
            />
          </div>

          {/* Quarter dots and labels */}
          <div className="flex justify-between items-center px-8 -mt-3">
            {QUARTERS.map((quarter, index) => (
              <div
                key={quarter.id}
                className="flex flex-col items-center cursor-pointer group"
                onMouseEnter={() => setActiveQuarter(quarter.id)}
              >
                {/* Dot */}
                <div
                  className={`w-6 h-6 rounded-full border-3 bg-white transition-all duration-300 ${
                    activeQuarter === quarter.id 
                      ? 'scale-125 shadow-lg' 
                      : 'hover:scale-110'
                  }`}
                  style={{ 
                    borderColor: quarter.color,
                    boxShadow: activeQuarter === quarter.id ? `0 0 20px ${quarter.color}40` : 'none'
                  }}
                />
                
                {/* Quarter label */}
                <div
                  className={`mt-3 px-3 py-1.5 rounded-full text-sm font-semibold transition-all duration-300 ${
                    activeQuarter === quarter.id
                      ? 'bg-white shadow-md scale-105'
                      : 'bg-gray-50 hover:bg-white hover:shadow-sm'
                  }`}
                  style={{
                    border: `2px solid ${quarter.color}`,
                    color: activeQuarter === quarter.id ? quarter.color : '#64748b'
                  }}
                >
                  {quarter.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic Milestones for Active Quarter */}
        <div className="transition-all duration-500">
          {/* Active Quarter Header */}
          <div className="mb-6 text-center">
            <div
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-lg font-semibold bg-white border-2 shadow-sm"
              style={{ 
                borderColor: QUARTERS.find(q => q.id === activeQuarter)?.color, 
                color: QUARTERS.find(q => q.id === activeQuarter)?.color 
              }}
            >
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: QUARTERS.find(q => q.id === activeQuarter)?.color }}
              />
              {QUARTERS.find(q => q.id === activeQuarter)?.label} Milestones
            </div>
          </div>

          {/* Milestone titles - Side by side layout */}
          <div className="flex flex-wrap justify-center gap-4 max-w-6xl mx-auto">
            {itemsForQuarter(activeQuarter).map((item) => (
              <div key={item.id} className="relative flex-shrink-0">
                <button
                  className="px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 bg-white border border-gray-200 hover:border-gray-300 hover:shadow-md text-slate-700 whitespace-nowrap"
                  onMouseEnter={() => setHoverItem(item.id)}
                  onMouseLeave={() => setHoverItem(null)}
                  style={{
                    borderColor: hoverItem === item.id ? QUARTERS.find(q => q.id === activeQuarter)?.color : undefined
                  }}
                >
                  {item.title}
                </button>

                {/* Hover description card */}
                {hoverItem === item.id && (
                  <div
                    className="absolute left-1/2 transform -translate-x-1/2 top-full mt-2 w-80 p-4 bg-white rounded-lg shadow-lg border-2 text-sm text-slate-700 leading-relaxed z-20 animate-fade-in"
                    style={{ borderColor: QUARTERS.find(q => q.id === activeQuarter)?.color }}
                  >
                    <div className="font-semibold mb-2 text-slate-800">{item.title}</div>
                    <div>{item.desc}</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default RoadmapSection;
