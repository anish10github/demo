import { Badge } from '@/components/ui/badge';
import { Mail, Feather, FileText, BarChart3 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const newsItems = [
  {
    id: 1,
    title: 'Immersive Studio Case Study',
    type: 'casestudy',
    summary: 'Impact stories loading — measurable results, real transformations.',
    badge: 'View',
    badgeGradient: 'from-pink-500 to-sky-400',
    iconBg: 'from-cyan-100 to-sky-200',
    iconColor: 'text-sky-600',
    accentPhrase: 'Impact stories loading',
    icon: BarChart3
  },
  {
    id: 2,
    title: 'Immersive Studio Newsletter',
    type: 'newsletter',
    summary: 'First edition drops soon — subscribe to be the first to know.',
    badge: 'View',
    badgeGradient: 'from-pink-500 to-sky-400',
    iconBg: 'from-blue-100 to-blue-200',
    iconColor: 'text-blue-600',
    accentPhrase: 'First edition drops soon',
    icon: Mail
  },
  {
    id: 3,
    title: 'Immersive Studio Blog',
    type: 'blog',
    summary: 'Ideas in motion — thought leadership articles arriving shortly.',
    badge: 'Next Release',
    badgeGradient: 'from-pink-500 to-orange-500',
    iconBg: 'from-pink-100 to-pink-200',
    iconColor: 'text-pink-600',
    accentPhrase: 'Ideas in motion',
    icon: Feather
  },
  {
    id: 4,
    title: 'Immersive Studio Whitepaper',
    type: 'whitepaper',
    summary: 'Drafting insights — deep dives on Gen AI in healthcare.',
    badge: 'Coming Soon',
    badgeGradient: 'from-gray-500 to-pink-500',
    iconBg: 'from-slate-100 to-blue-200',
    iconColor: 'text-slate-600',
    accentPhrase: 'Drafting insights',
    icon: FileText
  }
];

const NewsSection = () => {
  const navigate = useNavigate();
  
  const handleCardClick = (item: typeof newsItems[0]) => {
    if (item.type === 'casestudy') {
      navigate('/case-study');
    } else if (item.type === 'newsletter') {
      window.open('https://digital-studio.indegene.com/public/immersive-studio-newsletter/index.html', '_blank');
    } else {
      console.log(`Opening ${item.type}: ${item.title}`);
    }
  };

  const handleKeyDown = (event: React.KeyboardEvent, item: typeof newsItems[0]) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleCardClick(item);
    }
  };

  const highlightAccentPhrase = (text: string, accentPhrase: string) => {
    const parts = text.split(accentPhrase);
    if (parts.length === 1) return text;
    
    return (
      <>
        {parts[0]}
        <span className="text-primary font-semibold">{accentPhrase}</span>
        {parts[1]}
      </>
    );
  };

  return (
    <section id="news" className="py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 fade-in text-center">
          <h2 className="text-3xl font-bold text-gradient-pink-blue mb-2">
            Latest News & Updates
          </h2>
          <p className="text-muted-foreground">
            Stay up to date with our latest features, events, and announcements.
          </p>
        </div>

        {/* Single Row Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {newsItems.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <article
                key={item.id}
                className={`group relative bg-gradient-to-br ${item.iconBg} border border-border rounded-xl p-6 ${(item.type === 'casestudy' || item.type === 'newsletter') ? 'cursor-pointer hover:scale-105 hover:border-primary hover:shadow-lg focus-within:ring-2 focus-within:ring-primary' : ''} transition-all duration-300 fade-in`}
                style={{ animationDelay: `${index * 150}ms` }}
                onClick={(item.type === 'casestudy' || item.type === 'newsletter') ? () => handleCardClick(item) : undefined}
                onKeyDown={(item.type === 'casestudy' || item.type === 'newsletter') ? (e) => handleKeyDown(e, item) : undefined}
                tabIndex={(item.type === 'casestudy' || item.type === 'newsletter') ? 0 : -1}
                role={(item.type === 'casestudy' || item.type === 'newsletter') ? "button" : "article"}
                aria-label={(item.type === 'casestudy' || item.type === 'newsletter') ? `Learn more about ${item.title}` : item.title}
              >
                {/* Icon in colored square */}
                <div className="flex items-start gap-4 mb-4">
                  <div className={`flex-shrink-0 p-3 rounded-lg bg-gradient-to-br ${item.iconBg}`}>
                    <IconComponent className={`w-6 h-6 ${item.iconColor}`} />
                  </div>
                  
                  {/* Badge */}
                  <div className="ml-auto">
                    <Badge className={`px-3 py-1 rounded-full bg-gradient-to-r ${item.badgeGradient} text-white border-0 text-xs font-medium`}>
                      {item.badge}
                    </Badge>
                  </div>
                </div>

                {/* Content */}
                <div>
                  {/* Title */}
                  <h3 className="font-bold text-foreground text-lg leading-tight mb-3">
                    {item.title}
                  </h3>

                  {/* Summary with accent phrases */}
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {highlightAccentPhrase(item.summary, item.accentPhrase)}
                  </p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default NewsSection;
